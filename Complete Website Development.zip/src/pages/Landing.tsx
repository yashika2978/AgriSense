import { useAppNav } from '../App'

const HERO_IMG = 'https://images.unsplash.com/photo-1774695475379-88e1351e4922?w=1400&h=700&fit=crop&auto=format'
const FIELD_IMG = 'https://images.unsplash.com/photo-1743065528943-438a6a981631?w=600&h=400&fit=crop&auto=format'

export default function Landing() {
  const { navigate } = useAppNav()

  return (
    <div className="min-h-full bg-stone-50 overflow-x-hidden">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-stone-200">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LeafIcon className="w-6 h-6 text-green-700" />
            <span style={{ fontFamily: "'DM Serif Display', serif" }} className="text-xl font-normal text-green-900">AgriSense</span>
          </div>
          <button
            onClick={() => navigate('role-selection')}
            className="text-sm font-medium text-green-700 border border-green-600 px-4 py-1.5 rounded hover:bg-green-50 transition-colors"
          >
            Sign In
          </button>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative min-h-[88vh] flex items-center pt-14">
        <div
          className="absolute inset-0 bg-green-950"
          style={{
            backgroundImage: `url('${HERO_IMG}')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        >
          <div className="absolute inset-0 bg-green-950/65" />
        </div>
        <div className="relative z-10 max-w-6xl mx-auto px-4 py-20 md:py-28 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <div className="inline-flex items-center gap-2 bg-green-600/20 border border-green-400/30 text-green-200 text-xs font-medium px-3 py-1.5 rounded-full mb-6">
              <span className="w-1.5 h-1.5 bg-green-400 rounded-full inline-block" />
              AI-Assisted Crop Intelligence
            </div>
            <h1
              style={{ fontFamily: "'DM Serif Display', serif" }}
              className="text-4xl md:text-5xl lg:text-6xl font-normal text-white leading-tight mb-6"
            >
              Protect your crop before the damage spreads.
            </h1>
            <p className="text-green-100 text-lg leading-relaxed mb-8 max-w-lg">
              AI-assisted crop health detection, local risk forecasting and actionable agricultural guidance for farmers and extension workers.
            </p>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => navigate('role-selection')}
                className="bg-green-500 hover:bg-green-400 text-white font-semibold px-6 py-3 rounded-lg transition-colors shadow-lg"
              >
                Scan My Crop
              </button>
              <button
                onClick={() => navigate('role-selection')}
                className="bg-white/10 hover:bg-white/20 border border-white/30 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
              >
                Explore Risk Map
              </button>
            </div>
          </div>
          <div className="hidden md:block">
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 bg-green-400 rounded-lg flex items-center justify-center">
                  <ScanIcon className="w-4 h-4 text-white" />
                </div>
                <div>
                  <div className="text-white font-semibold text-sm">AI Diagnosis Active</div>
                  <div className="text-green-200 text-xs">Sanand, Gujarat</div>
                </div>
                <div className="ml-auto text-xs text-green-300">87% confidence</div>
              </div>
              <div className="bg-white/5 rounded-lg p-4 space-y-2">
                {['✓ Image quality checked', '✓ Crop identified: Rice', '✓ Symptom analysis complete', '⚠ Possible Leaf Blast detected'].map((s, i) => (
                  <div key={i} className={`text-sm ${i === 3 ? 'text-amber-300 font-medium' : 'text-green-200'}`}>{s}</div>
                ))}
              </div>
              <div className="mt-4 bg-amber-500/20 border border-amber-400/30 rounded-lg p-3">
                <div className="text-amber-200 text-xs font-semibold uppercase tracking-wide mb-1">Risk Level</div>
                <div className="flex items-center gap-2">
                  <div className="h-2 flex-1 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full w-3/4 bg-amber-400 rounded-full" />
                  </div>
                  <span className="text-white font-bold text-sm">High</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Capabilities */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 style={{ fontFamily: "'DM Serif Display', serif" }} className="text-3xl text-green-900 mb-3">
              Detect early. Act wisely. Protect every harvest.
            </h2>
            <p className="text-stone-500 max-w-xl mx-auto">
              From a single photo to regional intelligence — AgriSense supports the full cycle of crop health management.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: <ScanIcon className="w-6 h-6" />, title: 'AI Crop Diagnosis',
                desc: 'Upload a photo of any affected crop part. Get an instant AI assessment with explainable results.',
                color: 'green',
              },
              {
                icon: <ChartIcon className="w-6 h-6" />, title: 'Risk Forecasting',
                desc: '5-day disease and pest risk forecasts based on weather conditions, crop stage, and local reports.',
                color: 'amber',
              },
              {
                icon: <BookIcon className="w-6 h-6" />, title: 'Smart Advisories',
                desc: 'Integrated Pest Management guidance tailored to your crop, disease, and local conditions.',
                color: 'teal',
              },
              {
                icon: <MapIcon className="w-6 h-6" />, title: 'Field Intelligence',
                desc: 'Regional heat maps, cluster alerts, and validated case reports for extension officers.',
                color: 'blue',
              },
            ].map((c) => (
              <div key={c.title} className="border border-stone-200 rounded-xl p-6 hover:shadow-md transition-shadow">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-4 ${
                  c.color === 'green' ? 'bg-green-100 text-green-700' :
                  c.color === 'amber' ? 'bg-amber-100 text-amber-700' :
                  c.color === 'teal' ? 'bg-teal-100 text-teal-700' :
                  'bg-blue-100 text-blue-700'
                }`}>
                  {c.icon}
                </div>
                <h3 className="font-semibold text-stone-900 mb-2">{c.title}</h3>
                <p className="text-stone-500 text-sm leading-relaxed">{c.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Field image strip */}
      <section className="relative h-48 md:h-64 overflow-hidden">
        <img src={FIELD_IMG} alt="Agricultural fields" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-green-900/60 flex items-center justify-center">
          <p className="text-white text-lg md:text-2xl font-medium tracking-wide text-center px-4">
            Built for farmers · Extension teams · Agricultural authorities
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="py-14 bg-green-900 text-white">
        <div className="max-w-5xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[
            { value: '1,284', label: 'Field Reports' },
            { value: '892', label: 'Confirmed Cases' },
            { value: '24', label: 'Risk Zones Tracked' },
            { value: '8', label: 'Districts Covered' },
          ].map((s) => (
            <div key={s.label}>
              <div style={{ fontFamily: "'DM Serif Display', serif" }} className="text-3xl md:text-4xl text-green-200 mb-1">{s.value}</div>
              <div className="text-green-400 text-sm">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-white text-center">
        <div className="max-w-lg mx-auto px-4">
          <h2 style={{ fontFamily: "'DM Serif Display', serif" }} className="text-3xl text-green-900 mb-4">
            Start protecting your crop today.
          </h2>
          <p className="text-stone-500 mb-8">Choose your role and access the tools built for you.</p>
          <button
            onClick={() => navigate('role-selection')}
            className="bg-green-700 hover:bg-green-600 text-white font-semibold px-8 py-3 rounded-lg text-lg transition-colors shadow"
          >
            Get Started
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-green-950 text-green-400 py-8">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4 text-sm">
          <div className="flex items-center gap-2">
            <LeafIcon className="w-5 h-5" />
            <span style={{ fontFamily: "'DM Serif Display', serif" }} className="text-green-200 text-lg">AgriSense</span>
          </div>
          <p className="text-green-500 text-xs text-center">
            AI-assisted agricultural intelligence · For demonstration purposes only · Not a substitute for professional agronomic advice.
          </p>
        </div>
      </footer>
    </div>
  )
}

function LeafIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z" />
      <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12" />
    </svg>
  )
}

function ScanIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 7V5a2 2 0 0 1 2-2h2" /><path d="M17 3h2a2 2 0 0 1 2 2v2" />
      <path d="M21 17v2a2 2 0 0 1-2 2h-2" /><path d="M7 21H5a2 2 0 0 1-2-2v-2" />
      <line x1="3" y1="12" x2="21" y2="12" />
    </svg>
  )
}

function ChartIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="20" x2="18" y2="10" /><line x1="12" y1="20" x2="12" y2="4" />
      <line x1="6" y1="20" x2="6" y2="14" /><line x1="2" y1="20" x2="22" y2="20" />
    </svg>
  )
}

function BookIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" /><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
    </svg>
  )
}

function MapIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21" />
      <line x1="9" y1="3" x2="9" y2="18" /><line x1="15" y1="6" x2="15" y2="21" />
    </svg>
  )
}
