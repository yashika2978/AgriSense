import { useAppNav } from '../App'

export default function RoleSelection() {
  const { navigate } = useAppNav()
  return (
    <div className="min-h-full bg-stone-50 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-stone-200">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
          <button onClick={() => navigate('landing')} className="flex items-center gap-2 text-green-800 hover:text-green-600 transition-colors">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m15 18-6-6 6-6"/></svg>
            <span style={{ fontFamily: "'DM Serif Display', serif" }} className="text-xl">AgriSense</span>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-12">
        <div className="text-center mb-10">
          <h1 style={{ fontFamily: "'DM Serif Display', serif" }} className="text-3xl md:text-4xl text-green-900 mb-3">
            How will you use AgriSense?
          </h1>
          <p className="text-stone-500 text-base">Choose your role to access the tools built for you.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 w-full max-w-3xl">
          {/* Farmer card */}
          <div className="bg-white border-2 border-stone-200 hover:border-green-500 rounded-2xl p-8 transition-all hover:shadow-lg group cursor-pointer"
               onClick={() => navigate('farmer')}>
            <div className="w-14 h-14 bg-green-100 rounded-2xl flex items-center justify-center mb-5 group-hover:bg-green-600 transition-colors">
              <FarmerIcon className="w-7 h-7 text-green-700 group-hover:text-white transition-colors" />
            </div>
            <h2 className="text-xl font-semibold text-stone-900 mb-2">Farmer</h2>
            <p className="text-stone-500 text-sm leading-relaxed mb-6">
              Scan your crop, understand the risk and get actionable guidance for protecting your harvest.
            </p>
            <button
              onClick={(e) => { e.stopPropagation(); navigate('farmer') }}
              className="w-full bg-green-700 hover:bg-green-600 text-white font-semibold py-3 rounded-lg transition-colors"
            >
              Continue as Farmer
            </button>
          </div>

          {/* Officer card */}
          <div className="bg-white border-2 border-stone-200 hover:border-blue-500 rounded-2xl p-8 transition-all hover:shadow-lg group cursor-pointer"
               onClick={() => navigate('officer')}>
            <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center mb-5 group-hover:bg-blue-600 transition-colors">
              <OfficerIcon className="w-7 h-7 text-blue-700 group-hover:text-white transition-colors" />
            </div>
            <h2 className="text-xl font-semibold text-stone-900 mb-2">Extension Officer</h2>
            <p className="text-stone-500 text-sm leading-relaxed mb-6">
              Monitor reports, validate diagnoses and identify emerging crop health hotspots across your district.
            </p>
            <button
              onClick={(e) => { e.stopPropagation(); navigate('officer') }}
              className="w-full bg-blue-700 hover:bg-blue-600 text-white font-semibold py-3 rounded-lg transition-colors"
            >
              Continue as Officer
            </button>
          </div>
        </div>

        <p className="mt-8 text-xs text-stone-400 text-center max-w-sm">
          This is an AI-assisted prototype using simulated data. Not a substitute for professional agronomic advice.
        </p>
      </div>
    </div>
  )
}

function FarmerIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2a5 5 0 1 0 5 5c0-.3 0-.6-.05-.88" />
      <path d="M20 21a8 8 0 1 0-16 0" />
      <path d="m15 8 2 2 4-4" />
    </svg>
  )
}

function OfficerIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="3" width="20" height="14" rx="2" />
      <path d="M8 21h8" /><path d="M12 17v4" />
      <path d="M7 8h4" /><path d="M7 12h8" /><path d="M13 8h2" />
    </svg>
  )
}
