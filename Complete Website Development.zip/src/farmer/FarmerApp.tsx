import { useState, useEffect, useCallback } from 'react'
import { useAppNav } from '../App'

type FarmerPage =
  | 'home' | 'crop-selection' | 'image-upload' | 'ai-analysis'
  | 'diagnosis-result' | 'ipm-advisory' | 'expert-consultation'
  | 'report-case' | 'risk' | 'alerts' | 'alert-details'
  | 'my-reports' | 'report-details' | 'profile' | 'notifications'

type Language = 'en' | 'hi' | 'gu'

const NAV_LABELS: Record<Language, { home: string; scan: string; risk: string; alerts: string; profile: string }> = {
  en: { home: 'Home', scan: 'Scan', risk: 'Risk', alerts: 'Alerts', profile: 'Profile' },
  hi: { home: 'होम', scan: 'स्कैन', risk: 'जोखिम', alerts: 'अलर्ट', profile: 'प्रोफ़ाइल' },
  gu: { home: 'હોમ', scan: 'સ્કેન', risk: 'જોખમ', alerts: 'એલર્ટ', profile: 'પ્રોફ' },
}

const RICE_IMG = 'https://images.unsplash.com/photo-1561504935-4e7d4516a2d1?w=400&h=300&fit=crop&auto=format'

function getActiveTab(page: FarmerPage): string {
  if (['crop-selection','image-upload','ai-analysis','diagnosis-result','ipm-advisory','expert-consultation','report-case'].includes(page)) return 'scan'
  if (page === 'risk') return 'risk'
  if (['alerts','alert-details'].includes(page)) return 'alerts'
  if (page === 'profile') return 'profile'
  return 'home'
}

export default function FarmerApp() {
  const { navigate: globalNav } = useAppNav()
  const [page, setPage] = useState<FarmerPage>('home')
  const [lang, setLang] = useState<Language>('en')
  const [langOpen, setLangOpen] = useState(false)
  const [notifOpen, setNotifOpen] = useState(false)
  const [selectedCrop, setSelectedCrop] = useState('Rice')
  const [imageUploaded, setImageUploaded] = useState(false)
  const [analysisStep, setAnalysisStep] = useState(0)
  const [analysisComplete, setAnalysisComplete] = useState(false)
  const [reportSubmitted, setReportSubmitted] = useState(false)
  const [expertSubmitted, setExpertSubmitted] = useState(false)
  const [selectedAlertIdx, setSelectedAlertIdx] = useState(0)
  const [selectedReportIdx, setSelectedReportIdx] = useState(0)

  const nav = useCallback((p: FarmerPage) => {
    setPage(p)
    setNotifOpen(false)
    setLangOpen(false)
  }, [])

  const activeTab = getActiveTab(page)
  const labels = NAV_LABELS[lang]

  // Reset image/analysis when leaving scan flow
  useEffect(() => {
    if (!['image-upload','ai-analysis','diagnosis-result','ipm-advisory','expert-consultation','report-case'].includes(page)) {
      if (page === 'crop-selection') {
        setImageUploaded(false)
        setAnalysisStep(0)
        setAnalysisComplete(false)
        setReportSubmitted(false)
        setExpertSubmitted(false)
      }
    }
  }, [page])

  return (
    <div className="h-full overflow-hidden bg-stone-50">
      {/* Fixed Header */}
      <header className="fixed top-0 left-0 right-0 h-14 z-50 bg-white border-b border-stone-200 flex items-center px-4 gap-3">
        <div className="flex items-center gap-2 flex-shrink-0">
          <LeafIcon className="w-5 h-5 text-green-700" />
          <span style={{ fontFamily: "'DM Serif Display', serif" }} className="text-lg text-green-900">AgriSense</span>
        </div>
        <div className="flex items-center gap-1 text-xs text-stone-400 flex-shrink-0">
          <PinIcon className="w-3 h-3" />
          <span>Sanand, Gujarat</span>
        </div>
        <div className="flex-1" />
        {/* Language selector */}
        <div className="relative flex-shrink-0">
          <button onClick={() => { setLangOpen(!langOpen); setNotifOpen(false) }}
            className="flex items-center gap-1 text-xs text-green-700 font-medium border border-green-200 px-2 py-1 rounded hover:bg-green-50 transition-colors">
            {lang === 'en' ? 'EN' : lang === 'hi' ? 'हिंदी' : 'ગુ'}
            <ChevronIcon className="w-3 h-3" />
          </button>
          {langOpen && (
            <div className="absolute right-0 top-full mt-1 bg-white border border-stone-200 rounded-lg shadow-lg z-50 overflow-hidden">
              {(['en','hi','gu'] as Language[]).map((l) => (
                <button key={l} onClick={() => { setLang(l); setLangOpen(false) }}
                  className={`block w-full text-left px-4 py-2 text-xs hover:bg-stone-50 ${lang === l ? 'text-green-700 font-semibold' : 'text-stone-700'}`}>
                  {l === 'en' ? 'English' : l === 'hi' ? 'हिंदी' : 'ગુજરાતી'}
                </button>
              ))}
            </div>
          )}
        </div>
        {/* Notifications */}
        <div className="relative flex-shrink-0">
          <button onClick={() => { setNotifOpen(!notifOpen); setLangOpen(false) }}
            className="relative w-8 h-8 flex items-center justify-center rounded-full hover:bg-stone-100 transition-colors">
            <BellIcon className="w-5 h-5 text-stone-600" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
          </button>
          {notifOpen && (
            <div className="absolute right-0 top-full mt-1 w-72 bg-white border border-stone-200 rounded-xl shadow-xl z-50 overflow-hidden">
              <div className="px-4 py-3 border-b border-stone-100 flex items-center justify-between">
                <span className="font-semibold text-stone-800 text-sm">Notifications</span>
                <button onClick={() => setNotifOpen(false)} className="text-stone-400 hover:text-stone-600 text-xs">Close</button>
              </div>
              {NOTIFICATIONS.map((n, i) => (
                <div key={i} className={`px-4 py-3 border-b border-stone-50 ${i === 0 ? 'bg-green-50' : ''}`}>
                  <div className={`text-xs font-semibold mb-0.5 ${n.type === 'high' ? 'text-red-600' : n.type === 'weather' ? 'text-amber-600' : 'text-green-700'}`}>
                    {n.label}
                  </div>
                  <div className="text-xs text-stone-600 leading-relaxed">{n.msg}</div>
                  <div className="text-xs text-stone-400 mt-1">{n.time}</div>
                </div>
              ))}
            </div>
          )}
        </div>
        {/* Profile */}
        <button onClick={() => nav('profile')}
          className="w-8 h-8 bg-green-700 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
          RJ
        </button>
      </header>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex fixed left-0 top-14 bottom-0 w-56 z-40 bg-white border-r border-stone-200 flex-col pt-4 pb-4">
        <div className="px-3 mb-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-stone-400 px-3 mb-2">Navigation</div>
        </div>
        {SIDEBAR_ITEMS.map((item) => (
          <button key={item.key}
            onClick={() => nav(item.page as FarmerPage)}
            className={`flex items-center gap-3 mx-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
              activeTab === item.key
                ? 'bg-green-50 text-green-800 border border-green-200'
                : 'text-stone-600 hover:bg-stone-50 hover:text-stone-900'
            }`}>
            {item.icon}
            <span>{labels[item.key as keyof typeof labels]}</span>
            {item.key === 'alerts' && <span className="ml-auto text-xs bg-red-100 text-red-600 rounded-full px-1.5">3</span>}
          </button>
        ))}
        <div className="mt-auto mx-3 pt-4 border-t border-stone-100">
          <button onClick={() => globalNav('role-selection')}
            className="flex items-center gap-2 text-stone-500 text-xs hover:text-stone-700 px-3 py-2">
            <LogoutIcon className="w-4 h-4" />
            Switch Role
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main
        className="absolute left-0 right-0 bottom-16 md:bottom-0 overflow-y-auto"
        style={{ top: '56px' }}
        id="farmer-main"
      >
        <div className="md:ml-56 min-h-full">
          {/* Click outside handlers */}
          {(langOpen || notifOpen) && (
            <div className="fixed inset-0 z-30" onClick={() => { setLangOpen(false); setNotifOpen(false) }} />
          )}

          {page === 'home' && <FarmerHome nav={nav} />}
          {page === 'crop-selection' && <CropSelection nav={nav} setSelectedCrop={setSelectedCrop} />}
          {page === 'image-upload' && (
            <ImageUpload nav={nav} crop={selectedCrop} imageUploaded={imageUploaded} setImageUploaded={setImageUploaded} />
          )}
          {page === 'ai-analysis' && (
            <AIAnalysis nav={nav} step={analysisStep} setStep={setAnalysisStep} complete={analysisComplete} setComplete={setAnalysisComplete} />
          )}
          {page === 'diagnosis-result' && <DiagnosisResult nav={nav} crop={selectedCrop} />}
          {page === 'ipm-advisory' && <IPMAdvisory nav={nav} />}
          {page === 'expert-consultation' && <ExpertConsultation nav={nav} submitted={expertSubmitted} setSubmitted={setExpertSubmitted} />}
          {page === 'report-case' && <ReportCase nav={nav} submitted={reportSubmitted} setSubmitted={setReportSubmitted} />}
          {page === 'risk' && <RiskForecast nav={nav} />}
          {page === 'alerts' && <NearbyAlerts nav={nav} setSelectedAlertIdx={setSelectedAlertIdx} />}
          {page === 'alert-details' && <AlertDetails nav={nav} idx={selectedAlertIdx} />}
          {page === 'my-reports' && <MyReports nav={nav} setSelectedReportIdx={setSelectedReportIdx} />}
          {page === 'report-details' && <ReportDetails nav={nav} idx={selectedReportIdx} />}
          {page === 'profile' && <FarmerProfile nav={nav} lang={lang} setLang={setLang} />}
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 h-16 z-50 bg-white border-t border-stone-200 flex items-center">
        {SIDEBAR_ITEMS.map((item) => (
          <button key={item.key}
            onClick={() => nav(item.page as FarmerPage)}
            className={`flex-1 flex flex-col items-center justify-center gap-0.5 py-2 transition-colors ${
              activeTab === item.key ? 'text-green-700' : 'text-stone-400 hover:text-stone-600'
            }`}>
            <div className={`relative ${activeTab === item.key ? 'text-green-700' : ''}`}>
              {item.icon}
              {item.key === 'alerts' && <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full" />}
            </div>
            <span className="text-xs font-medium">{labels[item.key as keyof typeof labels]}</span>
            {activeTab === item.key && <span className="w-4 h-0.5 bg-green-600 rounded-full" />}
          </button>
        ))}
      </nav>
    </div>
  )
}

// ────────────────────────── SUB-PAGES ──────────────────────────

function FarmerHome({ nav }: { nav: (p: FarmerPage) => void }) {
  return (
    <div className="p-4 max-w-2xl mx-auto space-y-4 pb-4">
      {/* Greeting */}
      <div className="pt-2">
        <h1 className="text-xl font-semibold text-stone-900">Good morning, Farmer 👋</h1>
        <p className="text-stone-500 text-sm">Let's keep your crop healthy today.</p>
      </div>

      {/* Scan Card */}
      <div className="bg-green-800 rounded-2xl p-5 text-white">
        <div className="flex items-center gap-2 mb-1">
          <ScanIcon className="w-5 h-5 text-green-300" />
          <span className="font-semibold text-green-100 text-sm uppercase tracking-wide">Scan Your Crop</span>
        </div>
        <p className="text-green-200 text-sm mb-4 leading-relaxed">Take or upload a photo of an affected leaf, fruit or plant.</p>
        <div className="flex gap-3">
          <button onClick={() => nav('crop-selection')} className="flex-1 bg-green-600 hover:bg-green-500 text-white font-medium py-2.5 rounded-lg text-sm transition-colors flex items-center justify-center gap-2">
            <CameraIcon className="w-4 h-4" /> Take Photo
          </button>
          <button onClick={() => nav('crop-selection')} className="flex-1 bg-white/15 hover:bg-white/25 text-white font-medium py-2.5 rounded-lg text-sm transition-colors flex items-center justify-center gap-2">
            <UploadIcon className="w-4 h-4" /> Upload Image
          </button>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Check Risk', icon: <ShieldIcon className="w-5 h-5" />, color: 'amber', page: 'risk' as FarmerPage },
          { label: 'Nearby Alerts', icon: <MapPinIcon className="w-5 h-5" />, color: 'red', page: 'alerts' as FarmerPage },
          { label: 'My Reports', icon: <ReportIcon className="w-5 h-5" />, color: 'blue', page: 'my-reports' as FarmerPage },
        ].map((a) => (
          <button key={a.label} onClick={() => nav(a.page)}
            className="bg-white border border-stone-200 rounded-xl p-3 flex flex-col items-center gap-2 hover:shadow-sm hover:border-stone-300 transition-all">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
              a.color === 'amber' ? 'bg-amber-50 text-amber-600' :
              a.color === 'red' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'
            }`}>{a.icon}</div>
            <span className="text-xs font-medium text-stone-700 text-center leading-tight">{a.label}</span>
          </button>
        ))}
      </div>

      {/* Weather */}
      <div className="bg-white border border-stone-200 rounded-2xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-stone-800 text-sm">Today's Field Conditions</h2>
          <span className="text-xs text-stone-400">Sanand, Gujarat</span>
        </div>
        <div className="grid grid-cols-2 gap-3 mb-4">
          {[
            { label: 'Temperature', val: '29°C', icon: <ThermometerIcon className="w-4 h-4 text-orange-500" /> },
            { label: 'Humidity', val: '78%', icon: <DropletIcon className="w-4 h-4 text-blue-500" /> },
            { label: 'Rainfall Prob.', val: '65%', icon: <RainIcon className="w-4 h-4 text-blue-600" /> },
            { label: 'Wind', val: '12 km/h', icon: <WindIcon className="w-4 h-4 text-stone-500" /> },
          ].map((w) => (
            <div key={w.label} className="flex items-center gap-2">
              {w.icon}
              <div>
                <div className="text-xs text-stone-500">{w.label}</div>
                <div className="text-sm font-semibold text-stone-800">{w.val}</div>
              </div>
            </div>
          ))}
        </div>
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold text-amber-700 uppercase tracking-wide">Moderate Risk</span>
            <span className="w-2 h-2 bg-amber-500 rounded-full" />
          </div>
          <p className="text-xs text-amber-700 leading-relaxed">Warm and humid conditions may increase fungal disease risk.</p>
        </div>
      </div>
    </div>
  )
}

function CropSelection({ nav, setSelectedCrop }: { nav: (p: FarmerPage) => void; setSelectedCrop: (c: string) => void }) {
  const crops = ['Rice', 'Wheat', 'Cotton', 'Maize', 'Potato', 'Tomato', 'Chilli', 'Groundnut', "I don't know"]
  const [search, setSearch] = useState('')
  const filtered = crops.filter((c) => c.toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <BackButton label="Back to Home" onClick={() => nav('home')} />
      <h1 className="text-xl font-semibold text-stone-900 mb-1">What crop are you checking?</h1>
      <p className="text-stone-500 text-sm mb-4">Select the crop that is showing symptoms.</p>
      <div className="relative mb-4">
        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
        <input
          type="text"
          placeholder="Search crop..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 border border-stone-200 rounded-lg text-sm focus:outline-none focus:border-green-500 bg-white"
        />
      </div>
      <div className="grid grid-cols-3 gap-3">
        {filtered.map((crop) => (
          <button
            key={crop}
            onClick={() => { setSelectedCrop(crop); nav('image-upload') }}
            className="bg-white border border-stone-200 rounded-xl p-4 flex flex-col items-center gap-2 hover:border-green-500 hover:bg-green-50 hover:shadow-sm transition-all">
            <span className="text-2xl">{CROP_EMOJIS[crop] || '🌿'}</span>
            <span className="text-xs font-medium text-stone-700 text-center leading-tight">{crop}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

function ImageUpload({ nav, crop, imageUploaded, setImageUploaded }: {
  nav: (p: FarmerPage) => void; crop: string; imageUploaded: boolean; setImageUploaded: (v: boolean) => void
}) {
  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <BackButton label="Back to Crop Selection" onClick={() => nav('crop-selection')} />
      <h1 className="text-xl font-semibold text-stone-900 mb-1">Capture the affected area</h1>
      <p className="text-stone-500 text-sm mb-4">Crop selected: <span className="font-medium text-green-700">{crop}</span></p>

      {!imageUploaded ? (
        <>
          <div className="bg-stone-100 border-2 border-dashed border-stone-300 rounded-2xl h-48 flex flex-col items-center justify-center gap-2 mb-4">
            <CameraIcon className="w-10 h-10 text-stone-400" />
            <p className="text-stone-500 text-sm font-medium">Take a clear photo of the affected area</p>
            <p className="text-stone-400 text-xs">in good lighting</p>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-4 space-y-2">
            {['Keep the affected area in focus', 'Avoid blurry images', 'Capture one affected leaf clearly', 'Avoid very dark images'].map((tip) => (
              <div key={tip} className="flex items-center gap-2 text-sm text-green-800">
                <span className="text-green-600 flex-shrink-0">✓</span>
                <span>{tip}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-3">
            <button onClick={() => setImageUploaded(true)} className="flex-1 bg-green-700 hover:bg-green-600 text-white font-semibold py-3 rounded-lg flex items-center justify-center gap-2 transition-colors">
              <CameraIcon className="w-4 h-4" /> Take Photo
            </button>
            <button onClick={() => setImageUploaded(true)} className="flex-1 bg-white border border-stone-200 hover:bg-stone-50 text-stone-700 font-semibold py-3 rounded-lg flex items-center justify-center gap-2 transition-colors">
              <UploadIcon className="w-4 h-4" /> Upload from Gallery
            </button>
          </div>
        </>
      ) : (
        <>
          <div className="relative rounded-2xl overflow-hidden mb-4 bg-stone-200">
            <img src={RICE_IMG} alt="Uploaded crop photo" className="w-full h-52 object-cover" />
            <div className="absolute top-3 left-3 bg-green-600 text-white text-xs font-semibold px-2 py-1 rounded">
              Photo uploaded ✓
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={() => nav('ai-analysis')} className="flex-1 bg-green-700 hover:bg-green-600 text-white font-semibold py-3 rounded-lg flex items-center justify-center gap-2 transition-colors">
              <ScanIcon className="w-4 h-4" /> Analyze Crop
            </button>
            <button onClick={() => setImageUploaded(false)} className="flex-1 bg-white border border-stone-200 hover:bg-stone-50 text-stone-700 font-semibold py-3 rounded-lg transition-colors">
              Retake Photo
            </button>
          </div>
        </>
      )}
    </div>
  )
}

function AIAnalysis({ nav, step, setStep, complete, setComplete }: {
  nav: (p: FarmerPage) => void; step: number; setStep: (v: number) => void; complete: boolean; setComplete: (v: boolean) => void
}) {
  const steps = [
    { label: 'Image quality checked', done: step > 0, active: step === 0 },
    { label: 'Crop identified', done: step > 1, active: step === 1 },
    { label: 'Analyzing symptoms', done: step > 2, active: step === 2 },
    { label: 'Estimating severity', done: step > 3, active: step === 3 },
    { label: 'Checking local risk', done: step > 4, active: step === 4 },
  ]

  useEffect(() => {
    if (complete) return
    const timers: ReturnType<typeof setTimeout>[] = []
    ;[800, 1600, 2400, 3200, 4000].forEach((delay, i) => {
      timers.push(setTimeout(() => setStep(i + 1), delay))
    })
    timers.push(setTimeout(() => setComplete(true), 4800))
    return () => timers.forEach(clearTimeout)
  }, [])

  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <BackButton label="Back to Image Upload" onClick={() => nav('image-upload')} />
      <h1 className="text-xl font-semibold text-stone-900 mb-4">{complete ? 'Analysis Complete' : 'Analyzing your crop...'}</h1>

      {/* Image with scan overlay */}
      <div className="relative rounded-2xl overflow-hidden mb-5 bg-stone-200">
        <img src={RICE_IMG} alt="Crop being analyzed" className="w-full h-48 object-cover" />
        {!complete && (
          <>
            <div className="absolute inset-0 bg-green-900/20" />
            <div className="scan-line absolute left-0 right-0 h-0.5 bg-green-400 shadow-[0_0_8px_2px_rgba(74,222,128,0.6)]" />
          </>
        )}
        {complete && (
          <div className="absolute inset-0 bg-green-900/40 flex items-center justify-center">
            <div className="bg-white rounded-full p-3">
              <CheckIcon className="w-8 h-8 text-green-600" />
            </div>
          </div>
        )}
      </div>

      {/* Steps */}
      <div className="bg-white border border-stone-200 rounded-xl p-4 space-y-3 mb-4">
        {steps.map((s, i) => (
          <div key={i} className="flex items-center gap-3">
            <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
              s.done ? 'bg-green-500 text-white' :
              s.active ? 'bg-amber-400 progress-active' : 'bg-stone-200'
            }`}>
              {s.done ? <CheckIcon className="w-3 h-3" /> : s.active ? null : <span className="w-2 h-2 rounded-full bg-stone-400" />}
            </div>
            <span className={`text-sm ${s.done ? 'text-stone-700' : s.active ? 'text-amber-700 font-medium' : 'text-stone-400'}`}>
              {s.label}
            </span>
          </div>
        ))}
      </div>

      {complete && (
        <button onClick={() => nav('diagnosis-result')} className="w-full bg-green-700 hover:bg-green-600 text-white font-semibold py-3 rounded-lg transition-colors">
          View Diagnosis Result →
        </button>
      )}
    </div>
  )
}

function DiagnosisResult({ nav, crop }: { nav: (p: FarmerPage) => void; crop: string }) {
  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <BackButton label="Back to AI Analysis" onClick={() => nav('ai-analysis')} />
      <h1 className="text-xl font-semibold text-stone-900 mb-4">Crop Health Assessment</h1>

      <div className="relative rounded-2xl overflow-hidden mb-4 bg-stone-200">
        <img src={RICE_IMG} alt="Diagnosed crop" className="w-full h-40 object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-900/60 to-transparent flex items-end p-4">
          <div>
            <div className="text-white font-semibold">Possible {crop} Leaf Blast</div>
            <div className="text-stone-300 text-xs">AI-assisted assessment</div>
          </div>
        </div>
      </div>

      {/* Confidence + Severity */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="bg-white border border-stone-200 rounded-xl p-3 text-center">
          <div className="text-2xl font-bold text-green-700">87%</div>
          <div className="text-xs text-stone-500 mt-0.5">Confidence</div>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-center">
          <div className="text-sm font-bold text-red-700">HIGH</div>
          <div className="text-xs text-red-500 mt-0.5">Attention</div>
        </div>
        <div className="bg-white border border-stone-200 rounded-xl p-3 text-center">
          <div className="text-2xl font-bold text-orange-600">72%</div>
          <div className="text-xs text-stone-500 mt-0.5">Severity</div>
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-4">
        <p className="text-amber-800 text-sm leading-relaxed">
          Visible lesions are consistent with symptoms commonly associated with rice blast. The result is an AI-assisted assessment and should be confirmed if symptoms are severe or uncertain.
        </p>
      </div>

      {/* Why detected */}
      <div className="bg-white border border-stone-200 rounded-xl p-4 mb-4">
        <h3 className="font-semibold text-stone-800 text-sm mb-2">Why was this detected?</h3>
        <div className="space-y-1 mb-4">
          {['Leaf lesion pattern', 'Discoloration', 'Symptom distribution'].map((f) => (
            <div key={f} className="flex items-center gap-2 text-sm text-stone-600">
              <span className="w-1.5 h-1.5 bg-amber-500 rounded-full flex-shrink-0" />
              {f}
            </div>
          ))}
        </div>
        <h3 className="font-semibold text-stone-800 text-sm mb-2">What should you do now?</h3>
        <div className="space-y-1.5">
          {[
            'Inspect nearby plants for similar symptoms.',
            'Avoid practices that may increase disease pressure.',
            'Follow recommended IPM measures.',
            'Contact an extension worker if the condition is spreading.',
          ].map((a, i) => (
            <div key={i} className="flex items-start gap-2 text-sm text-stone-600">
              <span className="text-green-600 font-semibold flex-shrink-0 mt-0.5">{i + 1}.</span>
              {a}
            </div>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="space-y-2">
        <button onClick={() => nav('ipm-advisory')} className="w-full bg-green-700 hover:bg-green-600 text-white font-semibold py-3 rounded-lg transition-colors">
          View Treatment & IPM Advice
        </button>
        <button onClick={() => nav('expert-consultation')} className="w-full bg-white border border-green-600 text-green-700 hover:bg-green-50 font-semibold py-3 rounded-lg transition-colors">
          Ask an Expert
        </button>
        <button onClick={() => nav('report-case')} className="w-full bg-white border border-stone-200 text-stone-700 hover:bg-stone-50 font-semibold py-3 rounded-lg transition-colors">
          Report This Case
        </button>
        <button onClick={() => nav('crop-selection')} className="w-full text-stone-500 hover:text-stone-700 text-sm py-2 transition-colors">
          Scan Another Image
        </button>
      </div>
    </div>
  )
}

function IPMAdvisory({ nav }: { nav: (p: FarmerPage) => void }) {
  const [expanded, setExpanded] = useState<number | null>(0)
  const sections = [
    {
      num: '01', title: 'Monitor', color: 'blue',
      steps: ['Check plants daily for new lesions or spread of symptoms.', 'Mark affected areas in the field.', 'Track the number of affected plants over time.'],
    },
    {
      num: '02', title: 'Cultural Practices', color: 'green',
      steps: ['Avoid excess nitrogen fertilizer which promotes lush, susceptible growth.', 'Improve field drainage to reduce leaf wetness duration.', 'Maintain proper plant spacing for air circulation.'],
    },
    {
      num: '03', title: 'Biological / Low-risk Options', color: 'teal',
      steps: ['Apply Trichoderma-based products if available and recommended locally.', 'Use silicon-based amendments which can reduce blast susceptibility.', 'Consult your extension officer for locally approved biocontrol options.'],
    },
    {
      num: '04', title: 'Chemical Intervention', color: 'amber',
      steps: ['Only apply recommended fungicides after confirming diagnosis.', 'Follow the label instructions strictly — do not exceed the recommended dose.', 'Rotate chemical groups to prevent resistance development.', 'Contact your local extension officer for currently registered options.'],
    },
  ]
  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <BackButton label="Back to Diagnosis Result" onClick={() => nav('diagnosis-result')} />
      <h1 className="text-xl font-semibold text-stone-900 mb-1">Recommended Action Plan</h1>
      <div className="flex items-center gap-2 mb-4">
        <span className="text-sm text-stone-500">Rice Leaf Blast</span>
        <span className="w-1 h-1 bg-stone-300 rounded-full" />
        <span className="text-sm font-medium text-red-600">High Risk</span>
      </div>
      <div className="space-y-2 mb-4">
        {sections.map((s, i) => (
          <div key={i} className="bg-white border border-stone-200 rounded-xl overflow-hidden">
            <button onClick={() => setExpanded(expanded === i ? null : i)}
              className="w-full flex items-center gap-3 p-4 text-left hover:bg-stone-50 transition-colors">
              <span className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                s.color === 'blue' ? 'bg-blue-100 text-blue-700' :
                s.color === 'green' ? 'bg-green-100 text-green-700' :
                s.color === 'teal' ? 'bg-teal-100 text-teal-700' : 'bg-amber-100 text-amber-700'
              }`}>{s.num}</span>
              <span className="font-semibold text-stone-800 text-sm flex-1">{s.title}</span>
              <ChevronIcon className={`w-4 h-4 text-stone-400 transition-transform ${expanded === i ? 'rotate-180' : ''}`} />
            </button>
            {expanded === i && (
              <div className="px-4 pb-4 space-y-2">
                {s.steps.map((step, j) => (
                  <div key={j} className="flex items-start gap-2 text-sm text-stone-600">
                    <span className="w-1.5 h-1.5 bg-green-500 rounded-full flex-shrink-0 mt-1.5" />
                    {step}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-4">
        <h3 className="font-semibold text-red-800 text-sm mb-1">⚠ Safe Input Use</h3>
        <p className="text-red-700 text-xs leading-relaxed">Do not exceed the recommended dose. Avoid unnecessary pesticide application. Use appropriate protective equipment and follow local agricultural guidance.</p>
      </div>
      <button onClick={() => nav('expert-consultation')} className="w-full bg-green-700 hover:bg-green-600 text-white font-semibold py-3 rounded-lg transition-colors">
        Contact Extension Expert
      </button>
    </div>
  )
}

function ExpertConsultation({ nav, submitted, setSubmitted }: { nav: (p: FarmerPage) => void; submitted: boolean; setSubmitted: (v: boolean) => void }) {
  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <BackButton label="Back to Diagnosis Result" onClick={() => nav('diagnosis-result')} />
      <h1 className="text-xl font-semibold text-stone-900 mb-2">Get Expert Validation</h1>
      <div className="bg-stone-100 rounded-lg px-3 py-2 text-sm text-stone-700 mb-4 inline-flex items-center gap-2">
        <span>🌾</span> Rice · Possible Leaf Blast · 87% AI confidence
      </div>

      {!submitted ? (
        <>
          <div className="space-y-3 mb-5">
            {[
              { icon: '📋', title: 'Submit for Expert Review', desc: 'An agricultural extension expert will review your case within 24–48 hours.', action: () => setSubmitted(true) },
              { icon: '📍', title: 'Find Nearby Extension Support', desc: 'Locate extension offices and officers available in your area.', action: () => {} },
              { icon: '🔬', title: 'Refer for Laboratory Diagnosis', desc: 'Submit a plant sample to a certified laboratory for confirmation.', action: () => {} },
            ].map((opt) => (
              <button key={opt.title} onClick={opt.action}
                className="w-full text-left bg-white border border-stone-200 rounded-xl p-4 hover:border-green-500 hover:bg-green-50 transition-all">
                <div className="flex items-start gap-3">
                  <span className="text-xl">{opt.icon}</span>
                  <div>
                    <div className="font-semibold text-stone-800 text-sm mb-0.5">{opt.title}</div>
                    <div className="text-stone-500 text-xs leading-relaxed">{opt.desc}</div>
                  </div>
                </div>
              </button>
            ))}
          </div>
          <div className="bg-white border border-stone-200 rounded-xl p-4">
            <h3 className="font-semibold text-stone-800 text-sm mb-3">Case Review Timeline</h3>
            <div className="flex items-center gap-2">
              {['Pending', 'Under Review', 'Validated'].map((s, i) => (
                <div key={s} className="flex items-center gap-2 flex-1">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${i === 0 ? 'bg-amber-500 text-white' : 'bg-stone-200 text-stone-400'}`}>
                    {i + 1}
                  </div>
                  <span className={`text-xs ${i === 0 ? 'text-amber-700 font-medium' : 'text-stone-400'}`}>{s}</span>
                  {i < 2 && <div className="flex-1 h-px bg-stone-200" />}
                </div>
              ))}
            </div>
          </div>
        </>
      ) : (
        <div className="bg-green-50 border border-green-200 rounded-2xl p-6 text-center">
          <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <CheckIcon className="w-6 h-6 text-green-600" />
          </div>
          <h2 className="font-semibold text-green-800 mb-2">Case Submitted for Expert Review</h2>
          <p className="text-green-700 text-sm leading-relaxed mb-4">An extension expert will review your case within 24–48 hours. You will receive a notification once completed.</p>
          <div className="bg-white border border-green-200 rounded-lg p-3 text-left">
            <div className="text-xs text-stone-500 mb-1">Status</div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-amber-400 rounded-full animate-pulse" />
              <span className="text-sm font-medium text-amber-700">Pending Review</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function ReportCase({ nav, submitted, setSubmitted }: { nav: (p: FarmerPage) => void; submitted: boolean; setSubmitted: (v: boolean) => void }) {
  const [form, setForm] = useState({ crop: 'Rice', symptoms: '', severity: 'Moderate', date: '', pestCount: '' })
  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <BackButton label="Back to Diagnosis Result" onClick={() => nav('diagnosis-result')} />
      <h1 className="text-xl font-semibold text-stone-900 mb-4">Report Crop Condition</h1>

      {!submitted ? (
        <div className="space-y-4">
          <FormField label="Crop">
            <select value={form.crop} onChange={(e) => setForm({ ...form, crop: e.target.value })} className="w-full border border-stone-200 rounded-lg px-3 py-2.5 text-sm bg-white focus:outline-none focus:border-green-500">
              {['Rice','Wheat','Cotton','Maize','Potato','Tomato'].map((c) => <option key={c}>{c}</option>)}
            </select>
          </FormField>
          <FormField label="Location">
            <div className="border border-stone-200 rounded-lg px-3 py-2.5 bg-stone-50 text-sm text-stone-600 flex items-center gap-2">
              <PinIcon className="w-4 h-4 text-stone-400" /> Sanand, Gujarat
            </div>
          </FormField>
          <FormField label="Observed Symptoms">
            <textarea value={form.symptoms} onChange={(e) => setForm({ ...form, symptoms: e.target.value })}
              rows={3} placeholder="Describe what you see on the plant..."
              className="w-full border border-stone-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-green-500 resize-none" />
          </FormField>
          <FormField label="Severity">
            <div className="flex gap-2">
              {['Low','Moderate','High'].map((s) => (
                <button key={s} onClick={() => setForm({ ...form, severity: s })}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium border transition-colors ${
                    form.severity === s
                      ? s === 'Low' ? 'bg-green-100 border-green-500 text-green-700'
                        : s === 'Moderate' ? 'bg-amber-100 border-amber-500 text-amber-700'
                        : 'bg-red-100 border-red-500 text-red-700'
                      : 'bg-white border-stone-200 text-stone-600'
                  }`}>{s}</button>
              ))}
            </div>
          </FormField>
          <FormField label="Date Observed">
            <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })}
              className="w-full border border-stone-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-green-500 bg-white" />
          </FormField>
          <FormField label="Photo Attachment">
            <div className="border border-stone-200 rounded-lg overflow-hidden">
              <img src={RICE_IMG} alt="Attached photo" className="w-full h-28 object-cover" />
              <div className="px-3 py-2 text-xs text-stone-500 bg-stone-50">rice_leaf_scan.jpg · Attached</div>
            </div>
          </FormField>
          <FormField label="Pest Trap Count (Optional)">
            <input type="number" value={form.pestCount} onChange={(e) => setForm({ ...form, pestCount: e.target.value })}
              placeholder="Number of pests trapped"
              className="w-full border border-stone-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-green-500 bg-white" />
          </FormField>
          <button onClick={() => setSubmitted(true)} className="w-full bg-green-700 hover:bg-green-600 text-white font-semibold py-3 rounded-lg transition-colors">
            Submit Field Report
          </button>
        </div>
      ) : (
        <div className="bg-green-50 border border-green-200 rounded-2xl p-6 text-center">
          <div className="text-4xl mb-3">✓</div>
          <h2 className="font-semibold text-green-800 text-lg mb-2">Report Submitted</h2>
          <p className="text-green-700 text-sm leading-relaxed mb-4">Your observation has been added to the local crop-health monitoring system.</p>
          <button onClick={() => nav('my-reports')} className="bg-green-700 hover:bg-green-600 text-white font-semibold px-6 py-2.5 rounded-lg text-sm transition-colors">
            View My Reports
          </button>
        </div>
      )}
    </div>
  )
}

function RiskForecast({ nav }: { nav: (p: FarmerPage) => void }) {
  const days = [
    { day: 'Today', risk: 'Moderate', val: 68, color: 'amber' },
    { day: 'Tomorrow', risk: 'High', val: 82, color: 'red' },
    { day: 'Day 3', risk: 'High', val: 79, color: 'red' },
    { day: 'Day 4', risk: 'Moderate', val: 65, color: 'amber' },
    { day: 'Day 5', risk: 'Moderate', val: 60, color: 'amber' },
  ]
  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <BackButton label="Back to Home" onClick={() => nav('home')} />
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-semibold text-stone-900">Crop Health Risk</h1>
        <div className="flex items-center gap-1 text-xs text-stone-400">
          <PinIcon className="w-3 h-3" /> Sanand, Gujarat
        </div>
      </div>

      {/* Gauge */}
      <div className="bg-white border border-stone-200 rounded-2xl p-5 mb-4 text-center">
        <div className="text-sm font-semibold text-amber-700 uppercase tracking-wide mb-1">Moderate Risk</div>
        <div className="text-5xl font-bold text-stone-900 mb-1">68</div>
        <div className="text-stone-400 text-sm mb-4">/ 100</div>
        <div className="w-full bg-stone-100 rounded-full h-3 overflow-hidden mb-4">
          <div className="h-full rounded-full bg-gradient-to-r from-green-400 via-amber-400 to-red-500" style={{ width: '100%' }} />
        </div>
        <div className="relative w-full flex justify-center">
          <div className="absolute -top-7 flex flex-col items-center" style={{ left: '68%', transform: 'translateX(-50%)' }}>
            <div className="w-0.5 h-4 bg-stone-800 mx-auto" />
            <div className="text-xs font-bold text-stone-800 bg-white px-1 rounded">68</div>
          </div>
        </div>
        <p className="text-stone-600 text-sm leading-relaxed mt-2">
          Current conditions indicate a moderate risk of disease/pest spread over the next 3–5 days.
        </p>
      </div>

      {/* Factors */}
      <div className="bg-white border border-stone-200 rounded-xl p-4 mb-4">
        <h3 className="font-semibold text-stone-800 text-sm mb-3">Risk Factors</h3>
        <div className="grid grid-cols-2 gap-3 mb-3">
          {[
            { label: 'Temperature', val: '29°C', icon: '🌡' },
            { label: 'Humidity', val: '78%', icon: '💧' },
            { label: 'Rain probability', val: '65%', icon: '🌧' },
            { label: 'Crop Stage', val: 'Flowering', icon: '🌸' },
          ].map((f) => (
            <div key={f.label} className="bg-stone-50 rounded-lg p-2.5">
              <div className="text-base mb-0.5">{f.icon}</div>
              <div className="text-xs text-stone-500">{f.label}</div>
              <div className="text-sm font-semibold text-stone-800">{f.val}</div>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between text-sm border-t border-stone-100 pt-3">
          <div><span className="text-stone-500">Recent Field Reports:</span> <span className="font-semibold text-stone-800">12 nearby</span></div>
          <div><span className="text-stone-500">Pest Activity:</span> <span className="font-semibold text-amber-700">Moderate</span></div>
        </div>
      </div>

      {/* 5-day trend */}
      <div className="bg-white border border-stone-200 rounded-xl p-4 mb-4">
        <h3 className="font-semibold text-stone-800 text-sm mb-3">5-Day Risk Trend</h3>
        <div className="space-y-2">
          {days.map((d) => (
            <div key={d.day} className="flex items-center gap-3">
              <span className="text-xs text-stone-500 w-16 flex-shrink-0">{d.day}</span>
              <div className="flex-1 bg-stone-100 rounded-full h-2 overflow-hidden">
                <div className={`h-full rounded-full ${d.color === 'red' ? 'bg-red-500' : 'bg-amber-400'}`} style={{ width: `${d.val}%` }} />
              </div>
              <span className={`text-xs font-medium w-16 text-right ${d.color === 'red' ? 'text-red-600' : 'text-amber-600'}`}>{d.risk}</span>
            </div>
          ))}
        </div>
      </div>

      <button onClick={() => nav('ipm-advisory')} className="w-full bg-green-700 hover:bg-green-600 text-white font-semibold py-3 rounded-lg transition-colors">
        View Preventive Actions
      </button>
    </div>
  )
}

const NEARBY_ALERTS = [
  { level: 'high', levelLabel: 'High Risk', crop: 'Cotton', issue: 'Cotton pest activity', dist: '4.2 km away', color: 'red', region: 'Viramgam Road area' },
  { level: 'moderate', levelLabel: 'Moderate Risk', crop: 'Rice', issue: 'Rice disease reports', dist: '7.8 km away', color: 'orange', region: 'Bavla Road area' },
  { level: 'moderate', levelLabel: 'Moderate Risk', crop: 'Vegetables', issue: 'Vegetable pest reports', dist: '10.4 km away', color: 'orange', region: 'Changodar area' },
]

function NearbyAlerts({ nav, setSelectedAlertIdx }: { nav: (p: FarmerPage) => void; setSelectedAlertIdx: (i: number) => void }) {
  const [activeFilter, setActiveFilter] = useState('All')
  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <h1 className="text-xl font-semibold text-stone-900 mb-1">Crop Health Alerts Near You</h1>
      <p className="text-stone-500 text-sm mb-4">Sanand, Gujarat · Updated 2 hrs ago</p>

      {/* Map visual */}
      <div className="relative bg-green-50 border border-green-200 rounded-2xl h-52 mb-4 overflow-hidden">
        {/* Grid lines */}
        <svg className="absolute inset-0 w-full h-full opacity-20" preserveAspectRatio="none">
          {[1,2,3].map((i) => <line key={`h${i}`} x1="0" y1={`${i*25}%`} x2="100%" y2={`${i*25}%`} stroke="#166534" strokeWidth="1" />)}
          {[1,2,3,4].map((i) => <line key={`v${i}`} x1={`${i*20}%`} y1="0" x2={`${i*20}%`} y2="100%" stroke="#166534" strokeWidth="1" />)}
        </svg>
        {/* Road suggestions */}
        <svg className="absolute inset-0 w-full h-full opacity-10">
          <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#166534" strokeWidth="4" />
          <line x1="40%" y1="0" x2="40%" y2="100%" stroke="#166534" strokeWidth="4" />
        </svg>
        {/* Alert markers */}
        <div className="absolute" style={{ left: '28%', top: '22%' }}>
          <div className="w-5 h-5 bg-red-500 rounded-full border-2 border-white shadow-lg cursor-pointer hover:scale-110 transition-transform" onClick={() => { setSelectedAlertIdx(0); nav('alert-details') }} />
          <div className="absolute top-6 left-1/2 -translate-x-1/2 bg-red-500 text-white text-xs px-1.5 py-0.5 rounded whitespace-nowrap shadow">High Risk</div>
        </div>
        <div className="absolute" style={{ left: '68%', top: '55%' }}>
          <div className="w-5 h-5 bg-orange-400 rounded-full border-2 border-white shadow-lg cursor-pointer hover:scale-110 transition-transform" onClick={() => { setSelectedAlertIdx(1); nav('alert-details') }} />
          <div className="absolute top-6 left-1/2 -translate-x-1/2 bg-orange-400 text-white text-xs px-1.5 py-0.5 rounded whitespace-nowrap shadow">Moderate</div>
        </div>
        <div className="absolute" style={{ left: '62%', top: '75%' }}>
          <div className="w-4 h-4 bg-orange-400 rounded-full border-2 border-white shadow-md cursor-pointer" onClick={() => { setSelectedAlertIdx(2); nav('alert-details') }} />
        </div>
        {/* You are here */}
        <div className="absolute" style={{ left: '47%', top: '47%' }}>
          <div className="w-4 h-4 bg-blue-600 rounded-full border-2 border-white shadow-lg" />
          <div className="absolute top-5 left-1/2 -translate-x-1/2 text-xs text-blue-800 font-semibold whitespace-nowrap">You</div>
        </div>
        {/* Legend */}
        <div className="absolute bottom-2 right-2 flex gap-2 bg-white/80 rounded px-2 py-1">
          <div className="flex items-center gap-1"><div className="w-2 h-2 bg-red-500 rounded-full" /><span className="text-xs text-stone-600">High</span></div>
          <div className="flex items-center gap-1"><div className="w-2 h-2 bg-orange-400 rounded-full" /><span className="text-xs text-stone-600">Moderate</span></div>
          <div className="flex items-center gap-1"><div className="w-2 h-2 bg-green-500 rounded-full" /><span className="text-xs text-stone-600">Low</span></div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-2 overflow-x-auto pb-2 mb-4 scrollbar-hide">
        {['All','High Risk','Moderate','Cotton','Rice','Vegetable'].map((f) => (
          <button key={f} onClick={() => setActiveFilter(f)}
            className={`flex-shrink-0 text-xs font-medium px-3 py-1.5 rounded-full border transition-colors ${
              activeFilter === f ? 'bg-green-700 border-green-700 text-white' : 'bg-white border-stone-200 text-stone-600 hover:border-stone-300'
            }`}>{f}</button>
        ))}
      </div>

      {/* Alert list */}
      <div className="space-y-3">
        {NEARBY_ALERTS.map((a, i) => (
          <button key={i} onClick={() => { setSelectedAlertIdx(i); nav('alert-details') }}
            className="w-full text-left bg-white border border-stone-200 rounded-xl p-4 hover:shadow-sm hover:border-stone-300 transition-all">
            <div className="flex items-start gap-3">
              <div className={`w-3 h-3 rounded-full flex-shrink-0 mt-1 ${a.color === 'red' ? 'bg-red-500' : 'bg-orange-400'}`} />
              <div className="flex-1 min-w-0">
                <div className={`text-xs font-bold uppercase mb-0.5 ${a.color === 'red' ? 'text-red-600' : 'text-orange-600'}`}>{a.levelLabel}</div>
                <div className="font-semibold text-stone-800 text-sm">{a.issue}</div>
                <div className="text-stone-500 text-xs mt-0.5">{a.region}</div>
              </div>
              <div className="text-xs text-stone-400 flex-shrink-0">{a.dist}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}

function AlertDetails({ nav, idx }: { nav: (p: FarmerPage) => void; idx: number }) {
  const a = NEARBY_ALERTS[idx] || NEARBY_ALERTS[0]
  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <BackButton label="Back to Nearby Alerts" onClick={() => nav('alerts')} />
      <div className={`inline-flex items-center gap-1.5 text-xs font-bold uppercase px-2.5 py-1 rounded-full mb-3 ${a.color === 'red' ? 'bg-red-50 text-red-700' : 'bg-orange-50 text-orange-700'}`}>
        <span className={`w-2 h-2 rounded-full ${a.color === 'red' ? 'bg-red-500' : 'bg-orange-400'}`} />
        {a.levelLabel}
      </div>
      <h1 className="text-xl font-semibold text-stone-900 mb-1">{a.issue}</h1>
      <p className="text-stone-500 text-sm mb-4">{a.region} · {a.dist}</p>

      <div className="bg-white border border-stone-200 rounded-xl divide-y divide-stone-100 mb-4">
        {[
          { label: 'Crop Affected', val: a.crop },
          { label: 'Risk Level', val: a.levelLabel },
          { label: 'Distance', val: a.dist },
          { label: 'Reports in area', val: '12 reports' },
          { label: 'Confirmed cases', val: '5 confirmed' },
          { label: 'Last updated', val: '2 hours ago' },
        ].map((row) => (
          <div key={row.label} className="flex items-center justify-between px-4 py-3">
            <span className="text-sm text-stone-500">{row.label}</span>
            <span className="text-sm font-medium text-stone-800">{row.val}</span>
          </div>
        ))}
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-4">
        <h3 className="font-semibold text-amber-800 text-sm mb-1">Advisory</h3>
        <p className="text-amber-700 text-sm leading-relaxed">Inspect your {a.crop.toLowerCase()} crop carefully over the next few days. Early detection is key. Contact your extension officer if you observe similar symptoms.</p>
      </div>

      <button onClick={() => nav('crop-selection')} className="w-full bg-green-700 hover:bg-green-600 text-white font-semibold py-3 rounded-lg transition-colors">
        Scan My Crop Now
      </button>
    </div>
  )
}

const MY_REPORTS = [
  { crop: 'Rice', diagnosis: 'Leaf Blast', confidence: '87%', risk: 'High', status: 'Expert Review Pending', date: 'Aug 23, 2026', color: 'red' },
  { crop: 'Cotton', diagnosis: 'Healthy', confidence: '93%', risk: 'Low', status: 'Confirmed', date: 'Aug 18, 2026', color: 'green' },
  { crop: 'Wheat', diagnosis: 'Possible Rust', confidence: '71%', risk: 'Moderate', status: 'Under Review', date: 'Aug 12, 2026', color: 'amber' },
]

function MyReports({ nav, setSelectedReportIdx }: { nav: (p: FarmerPage) => void; setSelectedReportIdx: (i: number) => void }) {
  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <BackButton label="Back to Home" onClick={() => nav('home')} />
      <h1 className="text-xl font-semibold text-stone-900 mb-4">My Crop Health History</h1>
      <div className="space-y-3">
        {MY_REPORTS.map((r, i) => (
          <button key={i} onClick={() => { setSelectedReportIdx(i); nav('report-details') }}
            className="w-full text-left bg-white border border-stone-200 rounded-xl p-4 hover:shadow-sm hover:border-stone-300 transition-all">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="font-semibold text-stone-800 text-sm mb-1">{r.crop} — {r.diagnosis}</div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-stone-500">Confidence: <span className="font-medium text-stone-700">{r.confidence}</span></span>
                  <span className="text-stone-300">·</span>
                  <span className={`font-medium ${r.color === 'red' ? 'text-red-600' : r.color === 'green' ? 'text-green-600' : 'text-amber-600'}`}>{r.risk} Risk</span>
                </div>
                <div className="text-xs text-stone-400 mt-1">{r.date}</div>
              </div>
              <span className={`flex-shrink-0 text-xs font-medium px-2 py-0.5 rounded-full ${
                r.status === 'Confirmed' ? 'bg-green-100 text-green-700' :
                r.status === 'Expert Review Pending' ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'
              }`}>{r.status}</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}

function ReportDetails({ nav, idx }: { nav: (p: FarmerPage) => void; idx: number }) {
  const r = MY_REPORTS[idx] || MY_REPORTS[0]
  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <BackButton label="Back to My Reports" onClick={() => nav('my-reports')} />
      <h1 className="text-xl font-semibold text-stone-900 mb-4">Report Details</h1>
      <div className="bg-white border border-stone-200 rounded-2xl overflow-hidden mb-4">
        {r.crop === 'Rice' && <img src={RICE_IMG} alt="Crop" className="w-full h-36 object-cover" />}
        <div className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="font-semibold text-stone-900">{r.crop} — {r.diagnosis}</div>
              <div className="text-stone-500 text-xs mt-0.5">{r.date}</div>
            </div>
            <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${
              r.status === 'Confirmed' ? 'bg-green-100 text-green-700' :
              r.status === 'Expert Review Pending' ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'
            }`}>{r.status}</span>
          </div>
          <div className="grid grid-cols-3 gap-3 pt-3 border-t border-stone-100">
            <div className="text-center">
              <div className="text-lg font-bold text-green-700">{r.confidence}</div>
              <div className="text-xs text-stone-500">Confidence</div>
            </div>
            <div className="text-center border-x border-stone-100">
              <div className={`text-sm font-bold ${r.color === 'red' ? 'text-red-600' : r.color === 'green' ? 'text-green-600' : 'text-amber-600'}`}>{r.risk}</div>
              <div className="text-xs text-stone-500">Risk Level</div>
            </div>
            <div className="text-center">
              <div className="text-sm font-bold text-stone-700">Sanand</div>
              <div className="text-xs text-stone-500">Location</div>
            </div>
          </div>
        </div>
      </div>
      <div className="flex gap-3">
        <button onClick={() => nav('ipm-advisory')} className="flex-1 bg-green-700 hover:bg-green-600 text-white font-semibold py-3 rounded-lg text-sm transition-colors">
          View Advisory
        </button>
        <button onClick={() => nav('expert-consultation')} className="flex-1 bg-white border border-stone-200 text-stone-700 font-semibold py-3 rounded-lg text-sm transition-colors">
          Ask Expert
        </button>
      </div>
    </div>
  )
}

function FarmerProfile({ nav, lang, setLang }: { nav: (p: FarmerPage) => void; lang: Language; setLang: (l: Language) => void }) {
  return (
    <div className="p-4 max-w-2xl mx-auto pb-4">
      <BackButton label="Back to Home" onClick={() => nav('home')} />
      <h1 className="text-xl font-semibold text-stone-900 mb-4">My Profile</h1>

      {/* Avatar */}
      <div className="flex items-center gap-4 mb-6">
        <div className="w-16 h-16 bg-green-700 rounded-full flex items-center justify-center text-white text-2xl font-bold">RJ</div>
        <div>
          <div className="font-semibold text-stone-900">Ramesh Jadav</div>
          <div className="text-stone-500 text-sm">Sanand, Gujarat</div>
          <div className="text-green-600 text-xs mt-0.5">Farmer ID: AG-F-1042</div>
        </div>
      </div>

      <div className="space-y-3">
        <ProfileSection title="Personal Information">
          <ProfileRow label="Name" val="Ramesh Jadav" />
          <ProfileRow label="Location" val="Sanand, Gujarat" />
          <ProfileRow label="Village" val="Sanand Taluka" />
          <ProfileRow label="Land Size" val="4.5 acres" />
        </ProfileSection>

        <ProfileSection title="Crop Preferences">
          <div className="flex flex-wrap gap-2 px-4 pb-3">
            {['Rice','Cotton','Wheat'].map((c) => (
              <span key={c} className="text-xs bg-green-100 text-green-700 px-2.5 py-1 rounded-full font-medium">{c}</span>
            ))}
          </div>
        </ProfileSection>

        <ProfileSection title="Language">
          <div className="flex gap-2 px-4 pb-3">
            {(['en','hi','gu'] as Language[]).map((l) => (
              <button key={l} onClick={() => setLang(l)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors ${lang === l ? 'bg-green-700 border-green-700 text-white' : 'bg-white border-stone-200 text-stone-600'}`}>
                {l === 'en' ? 'English' : l === 'hi' ? 'हिंदी' : 'ગુજરાતી'}
              </button>
            ))}
          </div>
        </ProfileSection>

        <ProfileSection title="Notification Settings">
          {[
            { label: 'High Risk Alerts', on: true },
            { label: 'Weather Advisories', on: true },
            { label: 'Expert Case Updates', on: true },
            { label: 'Weekly Summary', on: false },
          ].map((n) => (
            <div key={n.label} className="flex items-center justify-between px-4 py-3 border-b border-stone-50 last:border-0">
              <span className="text-sm text-stone-700">{n.label}</span>
              <div className={`w-10 h-5 rounded-full transition-colors ${n.on ? 'bg-green-500' : 'bg-stone-200'} relative`}>
                <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${n.on ? 'translate-x-5' : 'translate-x-0.5'}`} />
              </div>
            </div>
          ))}
        </ProfileSection>
      </div>
    </div>
  )
}

// ────────────────────────── SHARED COMPONENTS ──────────────────────────

function BackButton({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex items-center gap-1.5 text-green-700 hover:text-green-600 text-sm font-medium mb-4 transition-colors">
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m15 18-6-6 6-6"/></svg>
      {label}
    </button>
  )
}

function ProfileSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white border border-stone-200 rounded-xl overflow-hidden">
      <div className="px-4 py-2.5 bg-stone-50 border-b border-stone-100">
        <h3 className="text-xs font-semibold uppercase tracking-wide text-stone-500">{title}</h3>
      </div>
      {children}
    </div>
  )
}

function ProfileRow({ label, val }: { label: string; val: string }) {
  return (
    <div className="flex items-center justify-between px-4 py-3 border-b border-stone-50 last:border-0">
      <span className="text-sm text-stone-500">{label}</span>
      <span className="text-sm font-medium text-stone-800">{val}</span>
    </div>
  )
}

function FormField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium text-stone-700 mb-1.5">{label}</label>
      {children}
    </div>
  )
}

// ────────────────────────── DATA & ICONS ──────────────────────────

const NOTIFICATIONS = [
  { type: 'high', label: 'High Risk Alert', msg: 'High disease activity detected near your location in Sanand area.', time: '2 hours ago' },
  { type: 'weather', label: 'Weather Advisory', msg: 'Humidity and rainfall conditions may increase fungal disease risk over next 3 days.', time: '5 hours ago' },
  { type: 'expert', label: 'Expert Update', msg: 'Your submitted crop report (Rice — Leaf Blast) has been reviewed by an officer.', time: 'Yesterday' },
]

const CROP_EMOJIS: Record<string, string> = {
  Rice: '🌾', Wheat: '🌾', Cotton: '🌿', Maize: '🌽', Potato: '🥔', Tomato: '🍅', Chilli: '🌶', Groundnut: '🥜', "I don't know": '❓',
}

const SIDEBAR_ITEMS = [
  { key: 'home', page: 'home', icon: <HomeIcon className="w-4 h-4" /> },
  { key: 'scan', page: 'crop-selection', icon: <ScanIcon className="w-4 h-4" /> },
  { key: 'risk', page: 'risk', icon: <ShieldIcon className="w-4 h-4" /> },
  { key: 'alerts', page: 'alerts', icon: <BellIcon className="w-4 h-4" /> },
  { key: 'profile', page: 'profile', icon: <UserIcon className="w-4 h-4" /> },
]

// Icon components
function HomeIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
}
function ScanIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><line x1="3" y1="12" x2="21" y2="12"/></svg>
}
function ShieldIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
}
function BellIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
}
function UserIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
}
function LeafIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/></svg>
}
function PinIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
}
function MapPinIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
}
function ReportIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
}
function CameraIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
}
function UploadIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg>
}
function SearchIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
}
function ChevronIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
}
function CheckIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
}
function ThermometerIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"/></svg>
}
function DropletIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>
}
function RainIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="16" y1="13" x2="16" y2="21"/><line x1="8" y1="13" x2="8" y2="21"/><line x1="12" y1="15" x2="12" y2="23"/><path d="M20 16.58A5 5 0 0 0 18 7h-1.26A8 8 0 1 0 4 15.25"/></svg>
}
function WindIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9.59 4.59A2 2 0 1 1 11 8H2m10.59 11.41A2 2 0 1 0 14 16H2m15.73-8.27A2.5 2.5 0 1 1 19.5 12H2"/></svg>
}
function LogoutIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
}
