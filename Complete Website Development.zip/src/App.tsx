import { useState, createContext, useContext } from 'react'
import Landing from './pages/Landing'
import RoleSelection from './pages/RoleSelection'
import FarmerApp from './farmer/FarmerApp'
import OfficerApp from './officer/OfficerApp'

export type AppView = 'landing' | 'role-selection' | 'farmer' | 'officer'

interface AppNavCtx {
  navigate: (v: AppView) => void
}

export const AppNav = createContext<AppNavCtx>({ navigate: () => {} })
export const useAppNav = () => useContext(AppNav)

export default function App() {
  const [view, setView] = useState<AppView>('landing')
  return (
    <AppNav.Provider value={{ navigate: setView }}>
      <div className="h-full">
        {view === 'landing' && <Landing />}
        {view === 'role-selection' && <RoleSelection />}
        {view === 'farmer' && <FarmerApp />}
        {view === 'officer' && <OfficerApp />}
      </div>
    </AppNav.Provider>
  )
}
