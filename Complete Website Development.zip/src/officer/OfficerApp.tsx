import { useState } from 'react'
import { useAppNav } from '../App'

type OfficerPage =
  | 'dashboard' | 'regional-heat-map' | 'focused-area'
  | 'validation' | 'case-validation' | 'alerts' | 'alert-detail'
  | 'reports' | 'profile'

const DISTRICT_DATA = [
  { id: 'mehsana', name: 'Mehsana', risk: 'low', reports: 14, confirmed: 8, trend: '+3%', threat: 'Whitefly', cx: 48, cy: 16 },
  { id: 'ahmedabad', name: 'Ahmedabad', risk: 'moderate', reports: 38, confirmed: 24, trend: '+9%', threat: 'Leaf Spot', cx: 62, cy: 34 },
  { id: 'sanand', name: 'Sanand', risk: 'high', reports: 48, confirmed: 31, trend: '↑18%', threat: 'Rice Leaf Blast', cx: 48, cy: 40 },
  { id: 'anand', name: 'Anand', risk: 'moderate', reports: 29, confirmed: 18, trend: '+6%', threat: 'Stem Borer', cx: 74, cy: 48 },
  { id: 'kheda', name: 'Kheda', risk: 'moderate', reports: 22, confirmed: 14, trend: '+5%', threat: 'Brown Plant Hopper', cx: 70, cy: 40 },
  { id: 'rajkot', name: 'Rajkot', risk: 'moderate', reports: 31, confirmed: 19, trend: '+14%', threat: 'Pink Bollworm', cx: 26, cy: 58 },
  { id: 'vadodara', name: 'Vadodara', risk: 'low', reports: 17, confirmed: 10, trend: '+2%', threat: 'Leaf Miner', cx: 68, cy: 62 },
  { id: 'surat', name: 'Surat', risk: 'emerging', reports: 21, confirmed: 12, trend: '+8%', threat: 'Thrips', cx: 58, cy: 80 },
]

function getRiskColor(risk: string) {
  if (risk === 'high') return { dot: 'bg-red-500', text: 'text-red-700', bg: 'bg-red-50 border-red-200', badge: 'bg-red-100 text-red-700', fill: '#ef4444' }
  if (risk === 'moderate') return { dot: 'bg-orange-400', text: 'text-orange-700', bg: 'bg-orange-50 border-orange-200', badge: 'bg-orange-100 text-orange-700', fill: '#fb923c' }
  if (risk === 'emerging') return { dot: 'bg-yellow-400', text: 'text-yellow-700', bg: 'bg-yellow-50 border-yellow-200', badge: 'bg-yellow-100 text-yellow-700', fill: '#facc15' }
  return { dot: 'bg-green-500', text: 'text-green-700', bg: 'bg-green-50 border-green-200', badge: 'bg-green-100 text-green-700', fill: '#22c55e' }
}

export default function OfficerApp() {
  const { navigate: globalNav } = useAppNav()
  const [page, setPage] = useState<OfficerPage>('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [selectedDistrict, setSelectedDistrict] = useState(DISTRICT_DATA[2])
  const [selectedCaseIdx, setSelectedCaseIdx] = useState(0)
  const [selectedAlertIdx, setSelectedAlertIdx] = useState(0)

  const nav = (p: OfficerPage) => {
    setPage(p)
    setSidebarOpen(false)
  }

  const NAV_ITEMS = [
    { key: 'dashboard', label: 'Dashboard', icon: <DashIcon className="w-4 h-4" /> },
    { key: 'regional-heat-map', label: 'Regional Heat Map', icon: <MapIcon className="w-4 h-4" /> },
    { key: 'validation', label: 'Validation', icon: <ValidIcon className="w-4 h-4" />, badge: '67' },
    { key: 'alerts', label: 'Alert Center', icon: <BellIcon className="w-4 h-4" />, badge: '5' },
    { key: 'reports', label: 'Reports & Analytics', icon: <ChartBarIcon className="w-4 h-4" /> },
    { key: 'profile', label: 'Profile', icon: <UserIcon className="w-4 h-4" /> },
  ]

  const activePage = ['focused-area'].includes(page) ? 'regional-heat-map' :
    ['case-validation'].includes(page) ? 'validation' :
    ['alert-detail'].includes(page) ? 'alerts' : page

  const SidebarContent = () => (
    <div className="flex flex-col h-full pt-4 pb-4">
      <div className="px-3 mb-2">
        <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 px-3 mb-2">Officer Tools</div>
      </div>
      {NAV_ITEMS.map((item) => (
        <button key={item.key}
          onClick={() => nav(item.key as OfficerPage)}
          className={`flex items-center gap-3 mx-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
            activePage === item.key
              ? 'bg-blue-50 text-blue-800 border border-blue-200'
              : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
          }`}>
          {item.icon}
          <span className="flex-1">{item.label}</span>
          {item.badge && <span className="text-xs bg-red-100 text-red-600 rounded-full px-1.5">{item.badge}</span>}
        </button>
      ))}
      <div className="mt-auto mx-3 pt-4 border-t border-slate-100">
        <button onClick={() => globalNav('role-selection')}
          className="flex items-center gap-2 text-slate-500 text-xs hover:text-slate-700 px-3 py-2">
          <LogoutIcon className="w-4 h-4" />
          Switch Role
        </button>
      </div>
    </div>
  )

  return (
    <div className="h-full overflow-hidden bg-slate-50">
      {/* Fixed Header */}
      <header className="fixed top-0 left-0 right-0 h-14 z-50 bg-white border-b border-slate-200 flex items-center px-4 gap-3">
        <button className="lg:hidden w-8 h-8 flex items-center justify-center rounded hover:bg-slate-100 transition-colors"
          onClick={() => setSidebarOpen(!sidebarOpen)}>
          <MenuIcon className="w-5 h-5 text-slate-600" />
        </button>
        <div className="flex items-center gap-2 flex-shrink-0">
          <ShieldCheckIcon className="w-5 h-5 text-blue-700" />
          <div>
            <span style={{ fontFamily: "'DM Serif Display', serif" }} className="text-lg text-blue-900">AgriSense</span>
            <span className="text-slate-400 text-xs ml-2 hidden sm:inline">Extension Intelligence</span>
          </div>
        </div>
        <div className="flex-1" />
        <div className="flex items-center gap-1.5 text-xs text-slate-500 flex-shrink-0">
          <PinIcon className="w-3 h-3" />
          <span className="hidden sm:inline">Ahmedabad District</span>
        </div>
        <select className="text-xs border border-slate-200 rounded px-2 py-1 text-slate-600 bg-white focus:outline-none hidden sm:block">
          <option>Aug 2026</option>
          <option>Jul 2026</option>
        </select>
        <div className="relative flex-shrink-0">
          <button className="relative w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 transition-colors">
            <BellIcon className="w-5 h-5 text-slate-600" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
          </button>
        </div>
        <button onClick={() => nav('profile')}
          className="w-8 h-8 bg-blue-700 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
          SO
        </button>
      </header>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-40" onClick={() => setSidebarOpen(false)}>
          <div className="absolute inset-0 bg-black/30" />
          <div className="absolute left-0 top-14 bottom-0 w-64 bg-white border-r border-slate-200 z-50" onClick={(e) => e.stopPropagation()}>
            <SidebarContent />
          </div>
        </div>
      )}

      {/* Desktop Sidebar */}
      <aside className="hidden lg:block fixed left-0 top-14 bottom-0 w-64 z-40 bg-white border-r border-slate-200">
        <SidebarContent />
      </aside>

      {/* Main Content */}
      <main className="absolute inset-0 overflow-y-auto" style={{ top: '56px' }}>
        <div className="lg:ml-64 min-h-full">
          {page === 'dashboard' && <OfficerDashboard nav={nav} />}
          {page === 'regional-heat-map' && (
            <RegionalHeatMap nav={nav} selectedDistrict={selectedDistrict} setSelectedDistrict={setSelectedDistrict} />
          )}
          {page === 'focused-area' && <FocusedArea nav={nav} district={selectedDistrict} />}
          {page === 'validation' && <PendingValidation nav={nav} setSelectedCaseIdx={setSelectedCaseIdx} />}
          {page === 'case-validation' && <CaseValidation nav={nav} caseIdx={selectedCaseIdx} />}
          {page === 'alerts' && <OfficerAlerts nav={nav} setSelectedAlertIdx={setSelectedAlertIdx} />}
          {page === 'alert-detail' && <OfficerAlertDetail nav={nav} idx={selectedAlertIdx} />}
          {page === 'reports' && <OfficerReports nav={nav} />}
          {page === 'profile' && <OfficerProfile nav={nav} />}
        </div>
      </main>
    </div>
  )
}

// ────────────────────────── OFFICER PAGES ──────────────────────────

function OfficerDashboard({ nav }: { nav: (p: OfficerPage) => void }) {
  const kpis = [
    { label: 'Total Field Reports', val: '1,284', change: '+43 this week', color: 'blue', icon: <ReportIcon className="w-5 h-5" /> },
    { label: 'High-Risk Areas', val: '24', change: '↑3 since last week', color: 'red', icon: <AlertIcon className="w-5 h-5" /> },
    { label: 'Pending Validation', val: '67', change: 'Needs attention', color: 'amber', icon: <ValidIcon className="w-5 h-5" /> },
    { label: 'Cases Confirmed', val: '892', change: '+18 today', color: 'green', icon: <CheckIcon className="w-5 h-5" /> },
  ]

  const threats = [
    { name: 'Rice Blast', change: '+18%', dir: 'up', severity: 'high' },
    { name: 'Pink Bollworm', change: '+14%', dir: 'up', severity: 'high' },
    { name: 'Wheat Rust', change: '+9%', dir: 'up', severity: 'moderate' },
    { name: 'Leaf Spot', change: '-4%', dir: 'down', severity: 'low' },
  ]

  const cropData = [
    { crop: 'Rice', pct: 34, count: 436 },
    { crop: 'Cotton', pct: 26, count: 334 },
    { crop: 'Wheat', pct: 18, count: 231 },
    { crop: 'Maize', pct: 12, count: 154 },
    { crop: 'Vegetables', pct: 10, count: 129 },
  ]

  return (
    <div className="p-4 lg:p-6 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 style={{ fontFamily: "'DM Serif Display', serif" }} className="text-2xl text-slate-900 mb-1">Regional Dashboard</h1>
        <p className="text-slate-500 text-sm">Ahmedabad District · Aug 25, 2026</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {kpis.map((k) => (
          <div key={k.label} className="bg-white border border-slate-200 rounded-xl p-4">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center mb-3 ${
              k.color === 'blue' ? 'bg-blue-100 text-blue-700' :
              k.color === 'red' ? 'bg-red-100 text-red-700' :
              k.color === 'amber' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'
            }`}>{k.icon}</div>
            <div className="text-2xl font-bold text-slate-900 mb-0.5">{k.val}</div>
            <div className="text-xs text-slate-500 leading-tight mb-1">{k.label}</div>
            <div className={`text-xs font-medium ${k.color === 'red' ? 'text-red-600' : k.color === 'amber' ? 'text-amber-600' : 'text-green-600'}`}>{k.change}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-4 mb-4">
        {/* Map overview */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-slate-800">Regional Crop Health Overview</h2>
            <button onClick={() => nav('regional-heat-map')} className="text-xs text-blue-600 hover:text-blue-500 font-medium">
              Full Heat Map →
            </button>
          </div>
          {/* Mini Gujarat map */}
          <div className="relative bg-slate-50 rounded-lg h-52 overflow-hidden border border-slate-100">
            <svg viewBox="0 0 100 100" className="w-full h-full">
              <path d="M 20 8 L 80 8 L 88 20 L 90 40 L 85 60 L 78 82 L 65 90 L 50 92 L 35 88 L 22 75 L 15 58 L 10 38 L 12 18 Z"
                fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="1" />
              {DISTRICT_DATA.map((d) => {
                const c = getRiskColor(d.risk)
                return (
                  <g key={d.id} className="cursor-pointer" onClick={() => nav('regional-heat-map')}>
                    <circle cx={d.cx} cy={d.cy} r="5.5" fill={c.fill} opacity="0.85" stroke="white" strokeWidth="1.2" />
                    <text x={d.cx} y={d.cy + 9.5} textAnchor="middle" fontSize="3.5" fill="#1e293b" fontFamily="DM Sans, sans-serif">{d.name}</text>
                  </g>
                )
              })}
            </svg>
            <div className="absolute bottom-2 right-2 flex gap-2 bg-white/80 rounded px-2 py-1">
              {[['red','High'],['orange','Moderate'],['yellow','Emerging'],['green','Low']].map(([c, l]) => (
                <div key={l} className="flex items-center gap-1">
                  <div className={`w-2 h-2 rounded-full ${c === 'red' ? 'bg-red-500' : c === 'orange' ? 'bg-orange-400' : c === 'yellow' ? 'bg-yellow-400' : 'bg-green-500'}`} />
                  <span className="text-xs text-slate-600">{l}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Emerging threats */}
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <h2 className="font-semibold text-slate-800 mb-3">Top Emerging Threats</h2>
          <div className="space-y-3">
            {threats.map((t) => (
              <div key={t.name} className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium text-slate-800">{t.name}</div>
                  <div className={`text-xs ${t.severity === 'high' ? 'text-red-500' : t.severity === 'moderate' ? 'text-amber-500' : 'text-green-500'}`}>
                    {t.severity}
                  </div>
                </div>
                <span className={`text-sm font-bold ${t.dir === 'up' ? 'text-red-600' : 'text-green-600'}`}>{t.change}</span>
              </div>
            ))}
          </div>
          <button onClick={() => nav('reports')} className="w-full mt-4 text-xs text-blue-600 hover:text-blue-500 font-medium text-left">
            View full analytics →
          </button>
        </div>
      </div>

      {/* Crop-wise distribution */}
      <div className="bg-white border border-slate-200 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-slate-800">Disease/Pest Reports — Last 30 Days</h2>
          <span className="text-xs text-slate-400">Crop-wise distribution</span>
        </div>
        <div className="space-y-2.5">
          {cropData.map((c) => (
            <div key={c.crop} className="flex items-center gap-3">
              <span className="text-sm text-slate-600 w-20 flex-shrink-0">{c.crop}</span>
              <div className="flex-1 bg-slate-100 rounded-full h-2 overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full" style={{ width: `${c.pct}%` }} />
              </div>
              <span className="text-xs text-slate-500 w-16 text-right">{c.count} reports</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function RegionalHeatMap({ nav, selectedDistrict, setSelectedDistrict }: {
  nav: (p: OfficerPage) => void
  selectedDistrict: typeof DISTRICT_DATA[0]
  setSelectedDistrict: (d: typeof DISTRICT_DATA[0]) => void
}) {
  const [activeFilters, setActiveFilters] = useState({ crop: 'All', risk: 'All', period: 'Last 30 days' })
  const [panelDistrict, setPanelDistrict] = useState<typeof DISTRICT_DATA[0] | null>(null)

  const handleDistrictClick = (d: typeof DISTRICT_DATA[0]) => {
    setSelectedDistrict(d)
    setPanelDistrict(d)
  }

  return (
    <div className="p-4 lg:p-6 max-w-6xl mx-auto">
      <BackButton label="Back to Officer Dashboard" onClick={() => nav('dashboard')} />
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-semibold text-slate-900">Regional Heat Map</h1>
        <span className="text-xs text-slate-400">Gujarat · Ahmedabad District</span>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-4">
        {[
          { label: 'Crop', options: ['All','Rice','Cotton','Wheat','Maize'], field: 'crop' as const },
          { label: 'Risk Level', options: ['All','High','Moderate','Emerging','Low'], field: 'risk' as const },
          { label: 'Period', options: ['Last 7 days','Last 30 days','Last 90 days'], field: 'period' as const },
        ].map((f) => (
          <select key={f.field}
            value={activeFilters[f.field]}
            onChange={(e) => setActiveFilters({ ...activeFilters, [f.field]: e.target.value })}
            className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-700 focus:outline-none focus:border-blue-500">
            {f.options.map((o) => <option key={o}>{o}</option>)}
          </select>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        {/* Map */}
        <div className="lg:col-span-2">
          <div className="bg-white border border-slate-200 rounded-xl p-4">
            <div className="relative bg-slate-50 rounded-lg overflow-hidden" style={{ paddingBottom: '75%' }}>
              <div className="absolute inset-0">
                <svg viewBox="0 0 100 100" className="w-full h-full">
                  {/* Gujarat simplified outline */}
                  <path d="M 18 6 L 82 6 L 90 18 L 92 38 L 88 58 L 80 78 L 68 90 L 52 93 L 36 90 L 22 78 L 14 58 L 10 36 L 12 18 Z"
                    fill="#f8fafc" stroke="#e2e8f0" strokeWidth="1.5" />
                  {/* District circles */}
                  {DISTRICT_DATA.map((d) => {
                    const c = getRiskColor(d.risk)
                    const isSelected = panelDistrict?.id === d.id
                    return (
                      <g key={d.id} className="cursor-pointer" onClick={() => handleDistrictClick(d)}>
                        {isSelected && <circle cx={d.cx} cy={d.cy} r="9" fill={c.fill} opacity="0.25" />}
                        <circle cx={d.cx} cy={d.cy} r={isSelected ? 7 : 6} fill={c.fill} opacity="0.9"
                          stroke={isSelected ? 'white' : 'white'} strokeWidth={isSelected ? 2 : 1.5} />
                        <text x={d.cx} y={d.cy + 11} textAnchor="middle" fontSize="3.8" fill="#1e293b" fontFamily="DM Sans, sans-serif" fontWeight="500">{d.name}</text>
                      </g>
                    )
                  })}
                </svg>
              </div>
            </div>
            {/* Map controls */}
            <div className="flex items-center justify-between mt-3">
              <div className="flex gap-1">
                {['−', '+'].map((btn, i) => (
                  <button key={i} className="w-7 h-7 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded text-sm font-bold transition-colors">{btn}</button>
                ))}
                <button className="px-2.5 h-7 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded text-xs transition-colors">Reset</button>
              </div>
              <div className="flex gap-3">
                {[['red','High'],['orange','Moderate'],['yellow','Emerging'],['green','Low']].map(([c, l]) => (
                  <div key={l} className="flex items-center gap-1">
                    <div className={`w-2.5 h-2.5 rounded-full ${c === 'red' ? 'bg-red-500' : c === 'orange' ? 'bg-orange-400' : c === 'yellow' ? 'bg-yellow-400' : 'bg-green-500'}`} />
                    <span className="text-xs text-slate-600">{l}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Detail panel or district list */}
        <div className="space-y-3">
          {panelDistrict ? (
            <div className={`bg-white border rounded-xl p-4 ${getRiskColor(panelDistrict.risk).bg}`}>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-slate-800">{panelDistrict.name}</h3>
                <button onClick={() => setPanelDistrict(null)} className="text-slate-400 hover:text-slate-600 text-sm">✕</button>
              </div>
              <div className={`inline-flex items-center gap-1 text-xs font-bold uppercase px-2 py-0.5 rounded-full mb-3 ${getRiskColor(panelDistrict.risk).badge}`}>
                {panelDistrict.risk} risk
              </div>
              <div className="space-y-2 mb-4">
                {[
                  { label: 'Primary Threat', val: panelDistrict.threat },
                  { label: 'Total Reports', val: panelDistrict.reports.toString() },
                  { label: 'Confirmed Cases', val: panelDistrict.confirmed.toString() },
                  { label: 'Recent Trend', val: panelDistrict.trend },
                  { label: 'Last Updated', val: '2 hrs ago' },
                ].map((row) => (
                  <div key={row.label} className="flex justify-between text-sm">
                    <span className="text-slate-500">{row.label}</span>
                    <span className="font-medium text-slate-800">{row.val}</span>
                  </div>
                ))}
              </div>
              <button onClick={() => nav('focused-area')}
                className="w-full bg-blue-700 hover:bg-blue-600 text-white text-sm font-semibold py-2.5 rounded-lg transition-colors">
                View Focused Area →
              </button>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <h3 className="font-semibold text-slate-700 text-sm mb-2">Click a district to view details</h3>
              <p className="text-slate-400 text-xs">Select any district on the map to see risk levels, reports, and actions.</p>
            </div>
          )}

          {/* All districts list */}
          <div className="bg-white border border-slate-200 rounded-xl p-4">
            <h3 className="font-semibold text-slate-800 text-sm mb-3">All Districts</h3>
            <div className="space-y-1.5">
              {DISTRICT_DATA.sort((a, b) => {
                const order = { high: 0, moderate: 1, emerging: 2, low: 3 }
                return (order[a.risk as keyof typeof order] || 99) - (order[b.risk as keyof typeof order] || 99)
              }).map((d) => (
                <button key={d.id} onClick={() => handleDistrictClick(d)}
                  className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-left hover:bg-slate-50 transition-colors ${panelDistrict?.id === d.id ? 'bg-slate-50' : ''}`}>
                  <div className={`w-2 h-2 rounded-full flex-shrink-0 ${getRiskColor(d.risk).dot}`} />
                  <span className="text-sm text-slate-700 flex-1">{d.name}</span>
                  <span className="text-xs text-slate-400">{d.reports} rpts</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function FocusedArea({ nav, district }: { nav: (p: OfficerPage) => void; district: typeof DISTRICT_DATA[0] }) {
  const c = getRiskColor(district.risk)
  return (
    <div className="p-4 lg:p-6 max-w-6xl mx-auto">
      <BackButton label="Back to Regional Heat Map" onClick={() => nav('regional-heat-map')} />
      <div className="flex items-start justify-between mb-4 gap-3">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">{district.name} Agricultural Zone</h1>
          <div className={`inline-flex items-center gap-1.5 text-xs font-bold uppercase px-2.5 py-0.5 rounded-full mt-1.5 ${c.badge}`}>
            {district.risk} risk · Score: {district.risk === 'high' ? 78 : district.risk === 'moderate' ? 62 : 45}/100
          </div>
        </div>
        <div className="text-right text-xs text-slate-400">
          <div>Last updated</div>
          <div className="font-medium text-slate-600">2 hours ago</div>
        </div>
      </div>

      {/* Detailed area map */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 mb-4">
        <h2 className="font-semibold text-slate-800 text-sm mb-3">Area Intelligence Map</h2>
        <div className="relative bg-green-50 rounded-lg overflow-hidden" style={{ height: '200px' }}>
          <svg className="absolute inset-0 w-full h-full opacity-10">
            {[1,2,3,4].map((i) => <line key={`h${i}`} x1="0" y1={`${i*20}%`} x2="100%" y2={`${i*20}%`} stroke="#166534" strokeWidth="1" />)}
            {[1,2,3,4,5].map((i) => <line key={`v${i}`} x1={`${i*16.6}%`} y1="0" x2={`${i*16.6}%`} y2="100%" stroke="#166534" strokeWidth="1" />)}
          </svg>
          {/* Hotspot clusters */}
          {[
            { x: '20%', y: '30%', type: 'disease', size: 'w-10 h-10', opacity: 'opacity-40' },
            { x: '55%', y: '20%', type: 'disease', size: 'w-7 h-7', opacity: 'opacity-30' },
            { x: '35%', y: '60%', type: 'pest', size: 'w-6 h-6', opacity: 'opacity-30' },
            { x: '75%', y: '50%', type: 'report', size: 'w-5 h-5', opacity: 'opacity-40' },
          ].map((h, i) => (
            <div key={i} className={`absolute ${h.size} rounded-full ${h.type === 'disease' ? 'bg-red-500' : h.type === 'pest' ? 'bg-orange-400' : 'bg-blue-400'} ${h.opacity} -translate-x-1/2 -translate-y-1/2`}
              style={{ left: h.x, top: h.y }} />
          ))}
          <div className="absolute bottom-2 right-2 flex gap-2 bg-white/80 rounded px-2 py-1">
            {[['red','Disease'],['orange','Pest'],['blue','Report']].map(([c, l]) => (
              <div key={l} className="flex items-center gap-1">
                <div className={`w-2 h-2 rounded-full ${c === 'red' ? 'bg-red-500' : c === 'orange' ? 'bg-orange-400' : 'bg-blue-400'}`} />
                <span className="text-xs text-slate-600">{l}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Analytics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
        {[
          { label: 'Total Reports', val: district.reports.toString(), color: 'blue' },
          { label: 'Confirmed Cases', val: district.confirmed.toString(), color: 'green' },
          { label: 'Pending Validation', val: '9', color: 'amber' },
          { label: 'High-Risk Clusters', val: '6', color: 'red' },
        ].map((s) => (
          <div key={s.label} className="bg-white border border-slate-200 rounded-xl p-3 text-center">
            <div className={`text-xl font-bold mb-0.5 ${s.color === 'blue' ? 'text-blue-700' : s.color === 'green' ? 'text-green-700' : s.color === 'amber' ? 'text-amber-700' : 'text-red-700'}`}>{s.val}</div>
            <div className="text-xs text-slate-500">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mb-4">
        {/* Threats */}
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <h3 className="font-semibold text-slate-800 text-sm mb-3">Active Threats</h3>
          <div className="flex items-center gap-3 mb-2">
            <span className="text-xs text-slate-500 w-24">Top Threat</span>
            <span className="font-semibold text-red-700 text-sm">{district.threat}</span>
            <span className="text-xs text-red-500 ml-auto">{district.trend}</span>
          </div>
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xs text-slate-500 w-24">Secondary</span>
            <span className="font-medium text-orange-700 text-sm">Stem Borer</span>
            <span className="text-xs text-orange-500 ml-auto">+5%</span>
          </div>
          <h3 className="font-semibold text-slate-800 text-sm mb-2">Why is this area at risk?</h3>
          <div className="space-y-1.5">
            {['High humidity (78%)', 'Recent rainfall events', 'Increasing field reports', 'Favorable crop stage (Flowering)'].map((r) => (
              <div key={r} className="flex items-center gap-2 text-xs text-slate-600">
                <span className="w-1.5 h-1.5 bg-red-400 rounded-full flex-shrink-0" />
                {r}
              </div>
            ))}
          </div>
        </div>

        {/* 14-day trend */}
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <h3 className="font-semibold text-slate-800 text-sm mb-3">Local Disease Activity — Last 14 Days</h3>
          <div className="flex items-end gap-1 h-24">
            {[4,6,5,8,7,9,12,11,14,13,16,15,18,20].map((v, i) => (
              <div key={i} className="flex-1 flex flex-col items-center justify-end">
                <div className="w-full rounded-t" style={{
                  height: `${(v / 20) * 100}%`,
                  backgroundColor: v > 12 ? '#ef4444' : v > 8 ? '#fb923c' : '#22c55e'
                }} />
              </div>
            ))}
          </div>
          <div className="flex justify-between text-xs text-slate-400 mt-1">
            <span>14 days ago</span>
            <span>Today</span>
          </div>
        </div>
      </div>

      {/* Crop distribution */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 mb-4">
        <h3 className="font-semibold text-slate-800 text-sm mb-3">Crop Distribution · Affected Area: 1,240 hectares</h3>
        <div className="space-y-2">
          {[['Rice', 48],['Cotton', 22],['Wheat', 18],['Vegetables', 12]].map(([crop, pct]) => (
            <div key={crop} className="flex items-center gap-3">
              <span className="text-sm text-slate-600 w-20">{crop}</span>
              <div className="flex-1 bg-slate-100 rounded-full h-2 overflow-hidden">
                <div className="h-full bg-green-500 rounded-full" style={{ width: `${pct}%` }} />
              </div>
              <span className="text-xs text-slate-500 w-8 text-right">{pct}%</span>
            </div>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {[
          { label: 'Review Pending Cases', action: () => nav('validation'), color: 'blue' },
          { label: 'Notify Farmers', action: () => nav('alerts'), color: 'green' },
          { label: 'View Reports', action: () => nav('reports'), color: 'slate' },
        ].map((a) => (
          <button key={a.label} onClick={a.action}
            className={`py-2.5 px-4 rounded-lg text-sm font-semibold transition-colors ${
              a.color === 'blue' ? 'bg-blue-700 hover:bg-blue-600 text-white' :
              a.color === 'green' ? 'bg-green-700 hover:bg-green-600 text-white' :
              'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}>{a.label}</button>
        ))}
      </div>
    </div>
  )
}

const PENDING_CASES = [
  { id: 'AG-1024', location: 'Sanand', crop: 'Cotton', assessment: 'Pink Bollworm', confidence: '76%', severity: 'High', submitted: '2 hrs ago' },
  { id: 'AG-1023', location: 'Kheda', crop: 'Rice', assessment: 'Leaf Blast', confidence: '82%', severity: 'High', submitted: '4 hrs ago' },
  { id: 'AG-1022', location: 'Anand', crop: 'Wheat', assessment: 'Wheat Rust', confidence: '69%', severity: 'Moderate', submitted: '6 hrs ago' },
  { id: 'AG-1021', location: 'Ahmedabad', crop: 'Maize', assessment: 'Stem Borer', confidence: '74%', severity: 'Moderate', submitted: '8 hrs ago' },
  { id: 'AG-1020', location: 'Rajkot', crop: 'Cotton', assessment: 'Healthy', confidence: '91%', severity: 'Low', submitted: '1 day ago' },
]

function PendingValidation({ nav, setSelectedCaseIdx }: { nav: (p: OfficerPage) => void; setSelectedCaseIdx: (i: number) => void }) {
  return (
    <div className="p-4 lg:p-6 max-w-6xl mx-auto">
      <BackButton label="Back to Officer Dashboard" onClick={() => nav('dashboard')} />
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-semibold text-slate-900">Pending Validation</h1>
        <span className="bg-amber-100 text-amber-700 text-xs font-bold px-2.5 py-1 rounded-full">{PENDING_CASES.length} pending</span>
      </div>

      {/* Desktop table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                {['Case ID', 'Location', 'Crop', 'AI Assessment', 'Confidence', 'Severity', 'Submitted', 'Action'].map((h) => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {PENDING_CASES.map((c, i) => (
                <tr key={c.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 text-sm font-mono text-blue-700 font-medium">{c.id}</td>
                  <td className="px-4 py-3 text-sm text-slate-700">{c.location}</td>
                  <td className="px-4 py-3 text-sm text-slate-700">{c.crop}</td>
                  <td className="px-4 py-3 text-sm font-medium text-slate-800">{c.assessment}</td>
                  <td className="px-4 py-3 text-sm">
                    <div className={`font-semibold ${parseInt(c.confidence) >= 80 ? 'text-green-700' : parseInt(c.confidence) >= 70 ? 'text-amber-700' : 'text-red-700'}`}>{c.confidence}</div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      c.severity === 'High' ? 'bg-red-100 text-red-700' :
                      c.severity === 'Moderate' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'
                    }`}>{c.severity}</span>
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-400 whitespace-nowrap">{c.submitted}</td>
                  <td className="px-4 py-3">
                    <button onClick={() => { setSelectedCaseIdx(i); nav('case-validation') }}
                      className="text-xs bg-blue-700 hover:bg-blue-600 text-white px-3 py-1.5 rounded font-medium transition-colors whitespace-nowrap">
                      Review
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function CaseValidation({ nav, caseIdx }: { nav: (p: OfficerPage) => void; caseIdx: number }) {
  const c = PENDING_CASES[caseIdx] || PENDING_CASES[0]
  const [action, setAction] = useState<'confirm' | 'correct' | null>(null)
  const [correction, setCorrection] = useState('')
  const [notes, setNotes] = useState('')
  const [submitted, setSubmitted] = useState(false)

  return (
    <div className="p-4 lg:p-6 max-w-3xl mx-auto">
      <BackButton label="Back to Pending Validation" onClick={() => nav('validation')} />
      <h1 className="text-xl font-semibold text-slate-900 mb-1">Expert Validation</h1>
      <p className="text-slate-500 text-sm mb-4">Case {c.id} · {c.location} · {c.crop}</p>

      {!submitted ? (
        <div className="space-y-4">
          {/* Image */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <img src={`https://images.unsplash.com/photo-1561504935-4e7d4516a2d1?w=600&h=250&fit=crop&auto=format`} alt="Field submission" className="w-full h-44 object-cover" />
            <div className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-800">AI Assessment: {c.assessment}</div>
                  <div className="text-slate-500 text-sm mt-0.5">Confidence: <span className="font-medium text-slate-800">{c.confidence}</span></div>
                </div>
                <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${
                  c.severity === 'High' ? 'bg-red-100 text-red-700' :
                  c.severity === 'Moderate' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'
                }`}>{c.severity}</span>
              </div>
            </div>
          </div>

          {/* Validation options */}
          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => { setAction('confirm') }}
              className={`p-4 rounded-xl border-2 text-left transition-all ${action === 'confirm' ? 'border-green-500 bg-green-50' : 'border-slate-200 bg-white hover:border-green-300'}`}>
              <div className="text-green-600 font-semibold text-sm mb-0.5">✓ Confirm Diagnosis</div>
              <div className="text-slate-500 text-xs">AI assessment is correct</div>
            </button>
            <button onClick={() => { setAction('correct') }}
              className={`p-4 rounded-xl border-2 text-left transition-all ${action === 'correct' ? 'border-amber-500 bg-amber-50' : 'border-slate-200 bg-white hover:border-amber-300'}`}>
              <div className="text-amber-700 font-semibold text-sm mb-0.5">✎ Correct Diagnosis</div>
              <div className="text-slate-500 text-xs">Provide correct assessment</div>
            </button>
          </div>

          {action === 'correct' && (
            <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Confirmed Pest / Disease</label>
                <select value={correction} onChange={(e) => setCorrection(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm bg-white focus:outline-none focus:border-blue-500">
                  <option value="">Select confirmed diagnosis</option>
                  {['Rice Leaf Blast','Cotton Bollworm','Wheat Rust','Stem Borer','Leaf Spot','Brown Plant Hopper','Healthy'].map((d) => (
                    <option key={d}>{d}</option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {action && (
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Expert Notes (optional)</label>
              <textarea value={notes} onChange={(e) => setNotes(e.target.value)}
                rows={3} placeholder="Add any observations or context..."
                className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-blue-500 resize-none" />
            </div>
          )}

          <button
            disabled={!action || (action === 'correct' && !correction)}
            onClick={() => setSubmitted(true)}
            className="w-full bg-blue-700 hover:bg-blue-600 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-semibold py-3 rounded-lg transition-colors">
            Submit Validation
          </button>
        </div>
      ) : (
        <div className="bg-green-50 border border-green-200 rounded-2xl p-6 text-center">
          <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <CheckIcon className="w-6 h-6 text-green-600" />
          </div>
          <h2 className="font-semibold text-green-800 mb-2">Case Validated</h2>
          <p className="text-green-700 text-sm mb-4">Case confirmed and added to regional surveillance data.</p>
          <div className="flex gap-3 justify-center">
            <button onClick={() => nav('validation')} className="bg-blue-700 hover:bg-blue-600 text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition-colors">
              Back to Pending
            </button>
            <button onClick={() => nav('regional-heat-map')} className="bg-white border border-slate-200 text-slate-700 text-sm font-semibold px-5 py-2.5 rounded-lg hover:bg-slate-50 transition-colors">
              View Heat Map
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

const OFFICER_ALERTS_DATA = [
  { priority: 'high', title: 'Cluster of cotton pest reports in 3 areas', body: 'Cluster of cotton pest reports detected in Rajkot, Sanand and Kheda areas. 47 reports in last 48 hours.', region: 'Rajkot / Sanand / Kheda', time: '1 hr ago' },
  { priority: 'monitor', title: 'Rice disease reports increasing', body: 'Rice disease reports have increased 18% over the last 7 days. Primary areas: Sanand and Ahmedabad.', region: 'Sanand / Ahmedabad', time: '3 hrs ago' },
  { priority: 'high', title: 'Unvalidated high-severity cases backlog', body: '12 high-severity cases have been pending validation for over 24 hours.', region: 'Multiple districts', time: '5 hrs ago' },
  { priority: 'monitor', title: 'Emerging wheat rust activity', body: 'Early-stage wheat rust reports detected in northern areas. Monitor closely.', region: 'Mehsana', time: '1 day ago' },
]

function OfficerAlerts({ nav, setSelectedAlertIdx }: { nav: (p: OfficerPage) => void; setSelectedAlertIdx: (i: number) => void }) {
  return (
    <div className="p-4 lg:p-6 max-w-4xl mx-auto">
      <h1 className="text-xl font-semibold text-slate-900 mb-1">Emerging Risk Alerts</h1>
      <p className="text-slate-500 text-sm mb-4">Ahmedabad District · {OFFICER_ALERTS_DATA.filter(a => a.priority === 'high').length} high priority</p>

      <div className="space-y-3">
        {OFFICER_ALERTS_DATA.map((a, i) => (
          <div key={i} className={`bg-white border rounded-xl p-4 ${a.priority === 'high' ? 'border-red-200' : 'border-slate-200'}`}>
            <div className="flex items-start gap-3">
              <div className={`w-2 h-2 rounded-full flex-shrink-0 mt-2 ${a.priority === 'high' ? 'bg-red-500' : 'bg-amber-400'}`} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className={`text-xs font-bold uppercase ${a.priority === 'high' ? 'text-red-600' : 'text-amber-600'}`}>
                    {a.priority === 'high' ? 'High Priority' : 'Monitor'}
                  </span>
                  <span className="text-xs text-slate-400">{a.time}</span>
                </div>
                <div className="font-semibold text-slate-800 text-sm mb-1">{a.title}</div>
                <div className="text-slate-500 text-xs leading-relaxed mb-3">{a.body}</div>
                <div className="flex flex-wrap gap-2">
                  <button onClick={() => { setSelectedAlertIdx(i); nav('alert-detail') }}
                    className="text-xs bg-blue-700 hover:bg-blue-600 text-white px-3 py-1.5 rounded font-medium transition-colors">
                    View Detail
                  </button>
                  <button onClick={() => nav('focused-area')}
                    className="text-xs bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 px-3 py-1.5 rounded font-medium transition-colors">
                    View Cluster
                  </button>
                  <button
                    className="text-xs bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 px-3 py-1.5 rounded font-medium transition-colors">
                    Notify Farmers
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function OfficerAlertDetail({ nav, idx }: { nav: (p: OfficerPage) => void; idx: number }) {
  const a = OFFICER_ALERTS_DATA[idx] || OFFICER_ALERTS_DATA[0]
  return (
    <div className="p-4 lg:p-6 max-w-3xl mx-auto">
      <BackButton label="Back to Officer Alerts" onClick={() => nav('alerts')} />
      <div className={`inline-flex items-center gap-1.5 text-xs font-bold uppercase px-2.5 py-1 rounded-full mb-3 ${a.priority === 'high' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}`}>
        {a.priority === 'high' ? 'High Priority Alert' : 'Monitor Alert'}
      </div>
      <h1 className="text-xl font-semibold text-slate-900 mb-1">{a.title}</h1>
      <p className="text-slate-500 text-sm mb-4">Region: {a.region} · {a.time}</p>

      <div className="bg-white border border-slate-200 rounded-xl p-4 mb-4">
        <p className="text-slate-700 leading-relaxed">{a.body}</p>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl divide-y divide-slate-100 mb-4">
        {[
          { label: 'Affected Area', val: a.region },
          { label: 'Alert Type', val: a.priority === 'high' ? 'High Priority' : 'Monitor' },
          { label: 'Reports Triggering Alert', val: '47 reports' },
          { label: 'Recommended Action', val: 'Assign extension visit; issue farmer advisory' },
        ].map((row) => (
          <div key={row.label} className="flex items-start gap-4 px-4 py-3">
            <span className="text-sm text-slate-500 w-40 flex-shrink-0">{row.label}</span>
            <span className="text-sm font-medium text-slate-800">{row.val}</span>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => nav('focused-area')} className="bg-blue-700 hover:bg-blue-600 text-white font-semibold py-3 rounded-lg text-sm transition-colors">
          View Cluster Map
        </button>
        <button onClick={() => nav('validation')} className="bg-white border border-slate-200 text-slate-700 font-semibold py-3 rounded-lg text-sm hover:bg-slate-50 transition-colors">
          Review Related Cases
        </button>
      </div>
    </div>
  )
}

function OfficerReports({ nav }: { nav: (p: OfficerPage) => void }) {
  const chartData = [
    { month: 'Mar', cases: 48 }, { month: 'Apr', cases: 62 }, { month: 'May', cases: 74 },
    { month: 'Jun', cases: 95 }, { month: 'Jul', cases: 112 }, { month: 'Aug', cases: 138 },
  ]
  const maxCases = Math.max(...chartData.map((d) => d.cases))

  return (
    <div className="p-4 lg:p-6 max-w-6xl mx-auto">
      <BackButton label="Back to Officer Dashboard" onClick={() => nav('dashboard')} />
      <h1 className="text-xl font-semibold text-slate-900 mb-4">Reports & Analytics</h1>

      {/* Summary row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Avg Response Time', val: '6.2 hrs', sub: 'From report to validation' },
          { label: 'Confirmation Rate', val: '69%', sub: 'AI accuracy validated' },
          { label: 'Hotspot Growth', val: '+24%', sub: 'vs last month' },
          { label: 'Preventive Actions', val: '38', sub: 'Interventions assigned' },
        ].map((s) => (
          <div key={s.label} className="bg-white border border-slate-200 rounded-xl p-4">
            <div className="text-xl font-bold text-slate-900 mb-0.5">{s.val}</div>
            <div className="text-sm text-slate-700 font-medium mb-0.5">{s.label}</div>
            <div className="text-xs text-slate-400">{s.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mb-4">
        {/* Disease trend chart */}
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <h2 className="font-semibold text-slate-800 text-sm mb-4">Disease Reports — Last 6 Months</h2>
          <div className="flex items-end gap-2 h-32">
            {chartData.map((d) => (
              <div key={d.month} className="flex-1 flex flex-col items-center gap-1">
                <div className="text-xs text-slate-500">{d.cases}</div>
                <div className="w-full bg-blue-500 rounded-t" style={{ height: `${(d.cases / maxCases) * 80}px` }} />
                <div className="text-xs text-slate-500">{d.month}</div>
              </div>
            ))}
          </div>
        </div>

        {/* District-wise risk */}
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <h2 className="font-semibold text-slate-800 text-sm mb-3">District-wise Risk</h2>
          <div className="space-y-2">
            {DISTRICT_DATA.slice(0, 5).map((d) => {
              const c = getRiskColor(d.risk)
              return (
                <div key={d.id} className="flex items-center gap-3">
                  <span className="text-sm text-slate-600 w-24">{d.name}</span>
                  <div className="flex-1 bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${(d.reports / 50) * 100}%`, backgroundColor: c.fill }} />
                  </div>
                  <span className="text-xs text-slate-500 w-12 text-right">{d.reports} rpts</span>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {/* Confirmed vs pending */}
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <h2 className="font-semibold text-slate-800 text-sm mb-4">Case Status Distribution</h2>
          <div className="flex items-center gap-4">
            <div className="relative w-28 h-28 flex-shrink-0">
              <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                <circle cx="18" cy="18" r="15.9155" fill="none" stroke="#e2e8f0" strokeWidth="3" />
                <circle cx="18" cy="18" r="15.9155" fill="none" stroke="#22c55e" strokeWidth="3"
                  strokeDasharray="69 31" strokeLinecap="round" />
                <circle cx="18" cy="18" r="15.9155" fill="none" stroke="#f59e0b" strokeWidth="3"
                  strokeDasharray="21 79" strokeDashoffset="-69" strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center text-sm font-bold text-slate-700">892</div>
            </div>
            <div className="space-y-2">
              {[['Confirmed', '69%', 'bg-green-500'], ['Under Review', '21%', 'bg-amber-400'], ['Pending', '10%', 'bg-slate-300']].map(([l, v, c]) => (
                <div key={l} className="flex items-center gap-2">
                  <div className={`w-2.5 h-2.5 rounded-full ${c}`} />
                  <span className="text-sm text-slate-700">{l}</span>
                  <span className="text-sm font-bold text-slate-900 ml-auto">{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Response time */}
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <h2 className="font-semibold text-slate-800 text-sm mb-3">Hotspot Growth Trend</h2>
          <div className="space-y-2.5">
            {['Rice Blast','Pink Bollworm','Wheat Rust','Leaf Spot'].map((t, i) => {
              const vals = [78, 58, 42, 22]
              return (
                <div key={t} className="flex items-center gap-3">
                  <span className="text-sm text-slate-600 flex-1">{t}</span>
                  <div className="w-24 bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div className={`h-full rounded-full ${i < 2 ? 'bg-red-500' : i === 2 ? 'bg-amber-400' : 'bg-green-500'}`} style={{ width: `${vals[i]}%` }} />
                  </div>
                  <span className="text-xs text-slate-500 w-8 text-right">{vals[i]}%</span>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

function OfficerProfile({ nav }: { nav: (p: OfficerPage) => void }) {
  return (
    <div className="p-4 lg:p-6 max-w-2xl mx-auto">
      <BackButton label="Back to Dashboard" onClick={() => nav('dashboard')} />
      <h1 className="text-xl font-semibold text-slate-900 mb-4">Officer Profile</h1>

      <div className="flex items-center gap-4 mb-6">
        <div className="w-16 h-16 bg-blue-700 rounded-full flex items-center justify-center text-white text-2xl font-bold">SO</div>
        <div>
          <div className="font-semibold text-slate-900">Sunita Officer</div>
          <div className="text-slate-500 text-sm">Extension Officer · Ahmedabad District</div>
          <div className="text-blue-600 text-xs mt-0.5">Officer ID: AGO-2241</div>
        </div>
      </div>

      <div className="space-y-3">
        <ProfileSection title="Officer Information">
          <ProfileRow label="Name" val="Sunita Officer" />
          <ProfileRow label="Employee ID" val="AGO-2241" />
          <ProfileRow label="Department" val="Agriculture Extension" />
          <ProfileRow label="Role" val="Senior Extension Officer" />
        </ProfileSection>
        <ProfileSection title="Assignment">
          <ProfileRow label="District" val="Ahmedabad District" />
          <ProfileRow label="Zone" val="North & Central Gujarat" />
          <ProfileRow label="Cases Validated" val="234 this year" />
        </ProfileSection>
        <ProfileSection title="Notification Settings">
          {[
            { label: 'High Priority Alerts', on: true },
            { label: 'New Validation Requests', on: true },
            { label: 'Regional Hotspot Alerts', on: true },
            { label: 'Daily Summary Report', on: false },
          ].map((n) => (
            <div key={n.label} className="flex items-center justify-between px-4 py-3 border-b border-slate-50 last:border-0">
              <span className="text-sm text-slate-700">{n.label}</span>
              <div className={`w-10 h-5 rounded-full ${n.on ? 'bg-blue-500' : 'bg-slate-200'} relative`}>
                <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${n.on ? 'translate-x-5' : 'translate-x-0.5'}`} />
              </div>
            </div>
          ))}
        </ProfileSection>
      </div>
    </div>
  )
}

// ────────────────────────── SHARED ──────────────────────────

function BackButton({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex items-center gap-1.5 text-blue-700 hover:text-blue-600 text-sm font-medium mb-4 transition-colors">
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m15 18-6-6 6-6"/></svg>
      {label}
    </button>
  )
}

function ProfileSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-100">
        <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500">{title}</h3>
      </div>
      {children}
    </div>
  )
}

function ProfileRow({ label, val }: { label: string; val: string }) {
  return (
    <div className="flex items-center justify-between px-4 py-3 border-b border-slate-50 last:border-0">
      <span className="text-sm text-slate-500">{label}</span>
      <span className="text-sm font-medium text-slate-800">{val}</span>
    </div>
  )
}

// Icons
function DashIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
}
function MapIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/><line x1="9" y1="3" x2="9" y2="18"/><line x1="15" y1="6" x2="15" y2="21"/></svg>
}
function ValidIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
}
function BellIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
}
function ChartBarIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/><line x1="2" y1="20" x2="22" y2="20"/></svg>
}
function UserIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
}
function ShieldCheckIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>
}
function PinIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
}
function MenuIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
}
function CheckIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
}
function AlertIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m10.29 3.86-8.2 14.15A2 2 0 0 0 3.82 21h16.36a2 2 0 0 0 1.73-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
}
function ReportIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
}
function LogoutIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
}
